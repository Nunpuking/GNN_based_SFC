RUNNING_MODE='test'
LEARNING_FASHION=$2
PREDICT_MODE=$3
ENVIRONMENT='Simulation'

TOPOLOGY_CHANGE_MODE=$6 # Should be the same configuraiton as training
DEPLOYMENT_CHANGE_MODE=$7 # Should be the same configuraiton as training
TOPOLOGY_CHANGE_MODE_TEST=$8 # Can choose any option regardless of training configuraiton
DEPLOYMENT_CHANGE_MODE_TEST=$9 # Can choose any option regardless of training configuraiton

PT=0
PRE_DELAY_COEFF=10 # for NodeLevel REINFORCE
PRE_RANDOM_TOPO_TAG=$4 # 'none' default
PRE_RANDOM_DEPL_ADD=$5 # 0 default

SAVE_DIR='./results/'
LOAD_DIR='./results/' #'./backup/'

N_RUNNING=1
BATCH_SIZE=1

if [ $LEARNING_FASHION == 'SL' ]
then
    MODEL_NAME='GG_RNN'
    LR=1e-4
elif [ $LEARNING_FASHION == 'REINFORCE' -a $PREDICT_MODE == 'NodeLevel' ]
then
    MODEL_NAME='GG_RNN'
    LR=1e-5
elif [ $LEARNING_FASHION == 'REINFORCE' -a $PREDICT_MODE == 'VNFLevel' ]
then
    MODEL_NAME='GG_RNN'
    LR=1e-6
elif [ $LEARNING_FASHION == 'AC' -a $PREDICT_MODE == 'NodeLevel' ]
then
    MODEL_NAME='GG_RNN_AC'
    LR=1e-5
elif [ $LEARNING_FASHION == 'AC' -a $PREDICT_MODE == 'VNFLevel' ]
then
    MODEL_NAME='GG_RNN_AC'
    LR=1e-6
elif [ $LEARNING_FASHION == 'A2C' -a $PREDICT_MODE == 'NodeLevel' ]
then
    MODEL_NAME='GG_RNN_AC'
    LR=1e-5
elif [ $LEARNING_FASHION == 'A2C' -a $PREDICT_MODE == 'VNFLevel' ]
then
    MODEL_NAME='GG_RNN_AC'
    LR=1e-6
elif [ $LEARNING_FASHION == 'PPO' -a $PREDICT_MODE == 'NodeLevel' ]
then
    MODEL_NAME='GG_RNN_PPO'
    LR=1e-5
elif [ $LEARNING_FASHION == 'PPO' -a $PREDICT_MODE == 'VNFLevel' ]
then
    MODEL_NAME='GG_RNN_PPO'
    LR=1e-5
elif [ $LEARNING_FASHION == 'DQN' ]
then
    MODEL_NAME='GG_RNN_Q'
    LR=1e-5
fi
OPT='RMSprop'

# About Model Architecture
GRU_STEPS=5
NODE_STATE_DIM=128
POSENC_NODE_DIM=4
MAX_N_NODES=50
RECURRENT_DELAY=0.1
ADJ_TEMPERATURE=2

if [ $PT == 1 -a $LEARNING_FASHION == 'SL' ]
then
    echo "Supervised Learning doesn't need pre-trained model!!"
    LOAD_PT_MODEL=''
elif [ $PT == 1 -a $LEARNING_FASHION == 'REINFORCE' -a $PREDICT_MODE == 'NodeLevel' ]
then
    LOAD_PT_MODEL='./results/SL_SFC_NodeLevel_RMSprop_0.0001LR_/model0.pth.best.pth'
elif [ $PT == 1 -a $LEARNING_FASHION == 'REINFORCE' -a $PREDICT_MODE == 'VNFLevel' ]
then
    LOAD_PT_MODEL='./results/SL_SFC_VNFLevel_RMSprop_0.0001LR_/model0.pth.best.pth'
elif [ $PT == 1 -a $LEARNING_FASHION == 'AC' -a $PREDICT_MODE == 'NodeLevel' ]
then
    LOAD_PT_MODEL='./results/SL_SFC_NodeLevel_RMSprop_0.0001LR_/model0.pth.best.pth'
elif [ $PT == 1 -a $LEARNING_FASHION == 'AC' -a $PREDICT_MODE == 'VNFLevel' ]
then
    LOAD_PT_MODEL='./results/SL_SFC_VNFLevel_RMSprop_0.0001LR_/model0.pth.best.pth'
elif [ $PT == 1 -a $LEARNING_FASHION == 'A2C' -a $PREDICT_MODE == 'NodeLevel' ]
then
    LOAD_PT_MODEL='./results/SL_SFC_NodeLevel_RMSprop_0.0001LR_/model0.pth.best.pth'
elif [ $PT == 1 -a $LEARNING_FASHION == 'A2C' -a $PREDICT_MODE == 'VNFLevel' ]
then
    LOAD_PT_MODEL='./results/SL_SFC_VNFLevel_RMSprop_0.0001LR_/model0.pth.best.pth'
elif [ $PT == 1 -a $LEARNING_FASHION == 'PPO' -a $PREDICT_MODE == 'NodeLevel' ]
then
    LOAD_PT_MODEL='./results/SL_SFC_NodeLevel_RMSprop_0.0001LR_/model0.pth.best.pth'
elif [ $PT == 1 -a $LEARNING_FASHION == 'PPO' -a $PREDICT_MODE == 'VNFLevel' ]
then
    LOAD_PT_MODEL='./results/SL_SFC_VNFLevel_RMSprop_0.0001LR_/model0.pth.best.pth'
elif [ $PT == 1 -a $LEARNING_FASHION == 'DQN' -a $PREDICT_MODE == 'NodeLevel' ]
then
    LOAD_PT_MODEL='./results/SL_GG_RNN_Q_SFC_NodeLevel_RMSprop_0.0001LR_/model0.pth'
elif [ $PT == 1 -a $LEARNING_FASHION == 'DQN' -a $PREDICT_MODE == 'VNFLevel' ]
then
    LOAD_PT_MODEL='./results/SL_GG_RNN_Q_SFC_VNFLevel_RMSprop_0.0001LR_/model0.pth'
else
    LOAD_PT_MODEL=''
fi

# Only for RL

RL_EPSILON=0.1
if [ $LEARNING_FASHION == 'REINFORCE' ]
then
    CONSIDER_MAXLAT=0
elif [ $LEARNING_FASHION == 'AC' ]
then
    CONSIDER_MAXLAT=1
elif [ $LEARNING_FASHION == 'A2C' ]
then
    CONSIDER_MAXLAT=1
elif [ $LEARNING_FASHION == 'PPO' ]
then
    CONSIDER_MAXLAT=1
elif [ $LEARNING_FASHION == 'DQN' -a $PREDICT_MODE == 'VNFLevel' ]
then
    CONSIDER_MAXLAT=1
else
    CONSIDER_MAXLAT=0
fi

DISCOUNT_FACTOR=0.999

if [ $PREDICT_MODE == 'NodeLevel' ]
then
    DELAY_COEFF=1 # 0 REINFORCE
elif [ $PREDICT_MODE == 'VNFLevel' ]
then
    DELAY_COEFF=10
fi

#if [ $PREDICT_MODE == 'NodeLevel' ]
#then
#    DELAY_COEFF=$PRE_DELAY_COEFF # REINFORCE
#elif [ $PREDICT_MODE == 'VNFLevel' -a $LEARNING_FASHION == 'SL' ]
#then
#    DELAY_COEFF=$PRE_DELAY_COEFF
#elif [ $PREDICT_MODE == 'VNFLevel' -a $LEARNING_FASHION == 'REINFORCE' ]
#then
#    DELAY_COEFF=$PRE_DELAY_COEFF
#elif [ $PREDICT_MODE == 'VNFLevel' -a $LEARNING_FASHION == 'DQN' ]
#then
#    DELAY_COEFF=10
#fi

### for DQN
REPLAY_BATCH_SIZE=32 #32
DQN_TARGET_UPDATE=1000 #1000

### for PPO
if [ $TOPOLOGY_CHANGE_MODE == 1 -a $DEPLOYMENT_CHANGE_MODE == 1 ]
then
    PPO_UPDATE_ITERS=8 #6 (org), 8 (CS2) : number of requests for updating
    PPO_EPOCH_RUN=2 #4 (org), 2 (CS2)
    PPO_EPS_CLIP=0.15 #0.15 (org), 0.15 (CS2)
else
    PPO_UPDATE_ITERS=6 #6 (org), 8 (CS2) : number of requests for updating
    PPO_EPOCH_RUN=4 #4 (org), 2 (CS2)
    PPO_EPS_CLIP=0.15 #0.15 (org), 0.15 (CS2)
fi

if [ $PREDICT_MODE == 'VNFLevel' ]
then
    RANDOM_TOPO_TAG=$PRE_RANDOM_TOPO_TAG
    RANDOM_DEPL_ADD=$PRE_RANDOM_DEPL_ADD #Fix
else
    RANDOM_TOPO_TAG='none'
    RANDOM_DEPL_ADD=0
fi
RANDOM_TOPO_TAG_TEST=$PRE_RANDOM_TOPO_TAG
RANDOM_DEPL_ADD_TEST=$PRE_RANDOM_DEPL_ADD

ABS_ADJ=0


CUDA_VISIBLE_DEVICES=$1 python3.8 run.py\
    --running_mode=$RUNNING_MODE --model_name=$MODEL_NAME --learning_fashion=$LEARNING_FASHION\
    --predict_mode=$PREDICT_MODE --environment=$ENVIRONMENT\
    --topology_change_mode=$TOPOLOGY_CHANGE_MODE --deployment_change_mode=$DEPLOYMENT_CHANGE_MODE\
    --topology_change_mode_test=$TOPOLOGY_CHANGE_MODE_TEST\
    --deployment_change_mode_test=$DEPLOYMENT_CHANGE_MODE_TEST\
    --save_dir=$SAVE_DIR --load_dir=$LOAD_DIR --n_running=$N_RUNNING\
    --lr=$LR --opt=$OPT\
    --rl_epsilon=$RL_EPSILON --delay_coeff=$DELAY_COEFF --discount_factor=$DISCOUNT_FACTOR\
    --GRU_steps=$GRU_STEPS --node_state_dim=$NODE_STATE_DIM --posenc_node_dim=$POSENC_NODE_DIM\
    --max_n_nodes=$MAX_N_NODES --recurrent_delay=$RECURRENT_DELAY\
    --adj_temperature=$ADJ_TEMPERATURE\
    --batch_size=$BATCH_SIZE --load_pt_model=$LOAD_PT_MODEL\
    --replay_batch_size=$REPLAY_BATCH_SIZE --dqn_target_update=$DQN_TARGET_UPDATE \
    --consider_maxlat=$CONSIDER_MAXLAT --random_topo_tag=$RANDOM_TOPO_TAG\
    --random_depl_add=$RANDOM_DEPL_ADD --abs_adj=$ABS_ADJ\
    --ppo_update_iters=$PPO_UPDATE_ITERS --ppo_epoch_run=$PPO_EPOCH_RUN --ppo_eps_clip=$PPO_EPS_CLIP\
    --random_topo_tag_test=$RANDOM_TOPO_TAG_TEST --random_depl_add_test=$RANDOM_DEPL_ADD_TEST
