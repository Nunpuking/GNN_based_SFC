import neptune
import time
import numpy as np
import copy

import torch
import torch.nn as nn
import torch.optim as optim
from torch.autograd import Variable

from data.BatchGenerator import MakeEncodingBatch, MakeDecodingBatch, MakeLabelBatch, ComputeSLAVs_Avg
from utils.TopologyUpdater import SetTopology, UpdateGenerations, UpdateCapacities,\
                                    MakeTDset
from utils.util_heo import open_log, training_manager, weights_initializer, timeSince
from utils.topology import TopologyDriver
from models.model import Call_Model
from tester.SL_Test import SL_test_main2 as SL_test_main

def node_to_edgeset(nodes):
    # testbed topology
    testbed_edgeset = {0: 0,\
                       1: 1,\
                       2: 1,\
                       3: 2,\
                       4: 2,\
                       5: 2,\
                       6: 3,\
                       7: 4,\
                       8: 5,\
                       9: 6,\
                       10: 7,\
                       11: 8,\
                       -1: -1}

    B = len(nodes)

    edges = copy.deepcopy(nodes.clone().detach())
    for b in range(B):
        edges[b] = testbed_edgeset[nodes[b].item()]
    return edges

def SL_train(TDset, B, model, optimizer, data_spec, predict_mode, device, abs_adj):
    '''
    B is the batch_size
    N is the number of nodes in the topology

    - INPUT
    TDset        : <B> class TD   , TopologyDrivers which is already set 
                                  with requests, deployments, and labels
    B            : int
    model        : class model
    optimizer    : class optimizer
    data_spec    : { 'max_reqs'         : MR,
                     'max_depls'        : MD,
                     'max_labels'       : ML,
                     'n_req_features'   : FR,
                     'n_depl_features'  : FD,
                     'n_label_features' : FL }
    predict_mode : str            , 'NodeLevel' or 'VNFLevel'
    deivce       : str            , device that the model is running on
    
    '''


    model.train()
    softmax = nn.Softmax(dim=1)
    criterion = nn.CrossEntropyLoss(reduction='none')

    N = TDset[0].n_nodes

    total_loss = 0
    total_acc = 0
    total_edge_acc = 0
    total_n_acc = 0
    n_predictions = 0
    total_slav = 0
    total_n_slav_count = 0

    for r_step in range(data_spec['max_reqs']):
        annotation, A_out, A_in, enc_mask, training_flag = MakeEncodingBatch(TDset, r_step, B,\
                                                                            abs_adj=abs_adj)
        if training_flag == False:
            break

        # Encoding Stage
        enc_out = model.encoder(annotation, A_out, A_in)

        # Decoding Stage
        train_loss = 0
        #_, E = enc_out.shape
        hidden = torch.zeros([B*N, 2*model.E])
        for gen_step in range(1000):
            from_node, vnf_now, vnf_all, dec_mask, training_flag\
                                     = MakeDecodingBatch(TDset, r_step, predict_mode, B)
            if training_flag == False:
                break

            label_node, label_vnf = MakeLabelBatch(TDset, r_step, gen_step, B)
            label_node = Variable(torch.from_numpy(label_node).type(torch.long)).to(device)
            label_vnf = Variable(torch.from_numpy(label_vnf).type(torch.long)).to(device)

            mask = enc_mask.reshape(B,1)*dec_mask
            loss_mask = [1 if sum(vals) > 0 else 0 for vals in mask]

            n_predictions += sum(loss_mask)

            loss_mask = Variable(torch.tensor(loss_mask)).to(device)
            logit_mask = mask.reshape(B*N)

            # Run decoder
            node_logits, vnf_logits, hidden = model(enc_out, from_node,\
                                                     vnf_now, vnf_all, logit_mask, hidden)

            # Compute losses
            node_loss = loss_mask * criterion(node_logits, label_node)
            node_probs = softmax(node_logits)

            node_pred = torch.argmax(node_probs, dim=1)

            for b in range(B):
                if not (torch.abs(torch.max(node_probs[b]) - torch.min(node_probs[b])) > 0.999):
                    total_acc += torch.eq(node_pred, label_node).type(torch.int).item()
                    total_edge_acc += torch.eq(node_to_edgeset(node_pred),\
                                               node_to_edgeset(label_node)).type(torch.int).item()
                    total_n_acc += 1

            if predict_mode == 'NodeLevel':
                vnf_probs = None
                for b in range(B):
                    tmp_vnf_logit = vnf_logits[b, node_pred[b], :].unsqueeze(0)
                    vnf_probs = tmp_vnf_logit if vnf_probs is None else\
                                torch.cat((vnf_probs, tmp_vnf_logit),0) # <B, 2>
                vnf_loss = loss_mask * criterion(vnf_probs, label_vnf)
                vnf_probs = softmax(vnf_probs)
                vnf_pred = torch.argmax(vnf_probs, dim=1)
                vnf_loss = vnf_loss.sum()
            else:
                vnf_loss = 0

            train_loss += node_loss.sum() + vnf_loss

            # Update Generations
            UpdateGenerations(TDset, r_step, label_node.cpu().numpy(),\
                                             B, label_vnf.cpu().numpy()) # Update with label


        # Backprop and Update
        train_loss.backward()
        nn.utils.clip_grad_norm(model.parameters(), 2)
        optimizer.step()
        optimizer.zero_grad()

        # Update Capacities
        UpdateCapacities(TDset, r_step, B)

        tmp_slav, tmp_n_slav_count= ComputeSLAVs_Avg(TDset, r_step, 'Label', predict_mode, B)

        total_loss += train_loss.item()
        total_slav += tmp_slav
        total_n_slav_count += tmp_n_slav_count

    total_slav /= total_n_slav_count

    return total_loss, total_slav, total_acc, total_edge_acc, total_n_acc, n_predictions

def SL_train_main(args, trainset, validset, neptune_log_names, checkpoint=None):
    print("-----Training Start-----")
    open_log(args.save_dir, dir=True, message="result_dir")
    open_log(args.save_subdir, dir=True, message="subdir")
    train_log = open_log(args.train_log_path, message="train")
    valid_log = open_log(args.valid_log_path, message="valid")

    train_log.write("{}\t{}\t{}\n".format('Iters', 'Loss', 'Time'))
    valid_log.write("{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\n".format(\
                        'Iters', 'ORGTEST_Fail', 'ORGTEST_DelayRatio', 'ORGTEST_Delay',\
                        'ORGTEST_Standard_Reward',\
                        'CHANGETEST1_Fail', 'CHANGETEST1_Delay', 'CHANGETEST1_Standard_Reward',\
                        'CHANGETEST2_Fail', 'CHANGETEST2_Delay', 'CHANGETEST2_Standard_Reward',\
                        'Time'))

    nt_train_loss, nt_valid_fail1, nt_valid_delayratio1, nt_valid_delay1, nt_valid_standard_reward1,\
                    nt_valid_fail2, nt_valid_delay2, nt_valid_standard_reward2,\
                    nt_valid_fail3, nt_valid_delay3, nt_valid_standard_reward3,\
                     = neptune_log_names

    manager = training_manager(args)

    TDset = MakeTDset(args.batch_size, args.environment, args.predict_mode, args.adj_temperature,\
                        args.recurrent_delay, args.topo_path, args.sfctypes_path,\
                        args.middlebox_path)

    checkpoint_epoch = 0
    skip_iters = False
    if checkpoint is not None:
        print("Model and optimizer are loaded from checkpoint!")
        checkpoint_epoch = checkpoint['epoch']
        checkpoint_iter = checkpoint['iters']
        model = checkpoint['model']
        optimizer = checkpoint['optimizer']
        skip_iters = True

    else:
        model = Call_Model(args, TDset[0].n_vnfs)
        model.apply(weights_initializer)

        print( sum( p.numel() for p in model.parameters() if p.requires_grad ) )

        if args.opt == 'Adam':
            optimizer = optim.Adam(model.parameters(), lr=args.lr)
        elif args.opt == 'RMSprop':
            optimizer = optim.RMSprop(model.parameters(), lr=args.lr)
        elif args.opt == 'Adadelta':
            optimizer = optim.Adadelta(model.parameters(), lr=args.lr)
        elif args.opt == 'SGD':
            optimizer = optim.SGD(model.parameters(), lr=args.lr, momentum=0.9)

    model.to(args.device)

    start_time = time.time()
    print_loss = 0
    print_slav = 0
    print_acc = 0
    print_edge_acc = 0
    print_n_acc = 0
    print_n_pred = 0
    best_eval = -9999999

    n_iters = 0
    print_iters = 0
    valid_iters = 0

    trainset_spec = trainset.dataset.data_spec

    early_stop = False
    for epoch in range(checkpoint_epoch, args.epochs):
        if early_stop is True:
            break
        model.train()

        for n_iter, (requests, deployments, labels) in enumerate(trainset):
            if skip_iters == True and n_iter < checkpoint_iter:
                continue
                
            current_batch_size = SetTopology(TDset, requests, deployments, labels, trainset_spec,\
                         learning_mode='SL')

            loss, slav, acc, edge_acc, n_acc, n_pred = SL_train(TDset, current_batch_size, model, optimizer,\
                                     trainset_spec, args.predict_mode, args.device, args.abs_adj)

            print_loss += loss
            print_slav += slav
            print_acc += acc
            print_edge_acc += edge_acc
            print_n_acc += n_acc
            print_n_pred += n_pred
            print_iters += current_batch_size
            valid_iters += current_batch_size
            n_iters += current_batch_size

            if print_iters >= args.print_iter:
                print_iters -= args.print_iter

                avg_loss = float(print_loss/print_n_pred)
                avg_slav = float(print_slav/args.print_iter)
                avg_acc = float(print_acc/print_n_acc)
                avg_edge_acc = float(print_edge_acc/print_n_acc)
                print_loss = 0
                print_slav = 0
                print_acc = 0
                print_edge_acc = 0
                print_n_acc = 0
                print_n_pred = 0

                print("ITER/EPOCH {}/{} | LOSS {:.4f} | BEST {:.4f} | SLAV {:.4f} | ACC {:.4f} | EdgeACC {:.4f} | PAT. {} LR_DECAY {} | {}".format(n_iters, epoch, avg_loss, best_eval, avg_slav, avg_acc, avg_edge_acc, manager.n_patience, manager.n_lr_decay,\
                    timeSince(start_time)))
                #neptune.log_metric(nt_train_loss, avg_loss)
                #neptune.log_metric('TRAIN_SLAV_LABEL', avg_slav)
                #neptune.log_metric('TRAIN_ACC', avg_acc)
                #neptune.log_metric('TRAIN_EdgeACC', avg_edge_acc)

                train_log.write("{}\t{}\t{}\n".format(\
                    n_iters, avg_loss, timeSince(start_time)))

            if valid_iters >= args.valid_iter:
                valid_iters -= args.valid_iter

                torch.save({'epoch':epoch,
                            'iters':n_iter,
                            'model':model,
                            'optimizer':optimizer,
                            }, args.model_path)
                print("=========================================")
                print("=============Validation Starts===========")
                print(args.save_subdir)

                valid_fail1, valid_delay1, valid_delayratio1, valid_naive_reward1,\
                valid_acc1, valid_edge_acc1\
                                    = SL_test_main(args, model, validset,\
                                     topology_change_mode_test = 0, deployment_change_mode_test = 0)
                #neptune.log_metric('VALID_ACC', valid_acc1)
                #neptune.log_metric('VALID_EdgeACC', valid_edge_acc1)
                if args.topology_change_mode_test == 1:
                    valid_fail2, valid_delay2, valid_delayratio2, valid_naive_reward2, _, _\
                                        = SL_test_main(args, model, validset,\
                                         topology_change_mode_test = 1, deployment_change_mode_test = 0)
                else:
                    valid_fail2, valid_delay2, valid_delayratio2, valid_naive_reward2 = 0, 0, 0, 0
                if args.topology_change_mode_test == 1 and \
                    args.deployment_change_mode_test == 1:
                    valid_fail3, valid_delay3, valid_delayratio3, valid_naive_reward3, _, _\
                                        = SL_test_main(args, model, validset,\
                                         topology_change_mode_test = 1, deployment_change_mode_test = 1)
                else:
                    valid_fail3, valid_delay3, valid_delayratio3, valid_naive_reward3 = 0, 0, 0, 0

                print("OriginalTest - FAIL : {:.4f} | DELAY : {:.4f} | STANDARD_REWARD : {:.4f} | ACC : {:.4f} | EdgeACC : {:.4f}"\
                        .format(valid_fail1, valid_delayratio1, valid_naive_reward1, valid_acc1, valid_edge_acc1))
                print("ChangeTest1 - FAIL : {:.4f} | DELAY : {:.4f} | STANDARD_REWARD : {:.4f}"\
                        .format(valid_fail2, valid_delayratio2, valid_naive_reward2))
                print("ChangeTest2 - FAIL : {:.4f} | DELAY : {:.4f} | STANDARD_REWARD : {:.4f}"\
                        .format(valid_fail3, valid_delayratio3, valid_naive_reward3))
                print("=========================================")
                #neptune.log_metric(nt_valid_fail1, valid_fail1)
                #neptune.log_metric(nt_valid_delayratio1, valid_delayratio1)
                #neptune.log_metric(nt_valid_delay1, valid_delay1)
                #neptune.log_metric(nt_valid_standard_reward1, valid_naive_reward1)
                #neptune.log_metric(nt_valid_fail2, valid_fail2)
                #neptune.log_metric(nt_valid_delay2, valid_delay2)
                #neptune.log_metric(nt_valid_standard_reward2, valid_naive_reward2)
                #neptune.log_metric(nt_valid_fail3, valid_fail3)
                #neptune.log_metric(nt_valid_delay3, valid_delay3)
                #neptune.log_metric(nt_valid_standard_reward3, valid_naive_reward3)
                valid_log.write("{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\n".format(\
                    n_iters, valid_fail1, valid_delayratio1, valid_delay1, valid_naive_reward1,\
                    valid_fail2, valid_delay2, valid_naive_reward2,\
                    valid_fail3, valid_delay3, valid_naive_reward3, timeSince(start_time)))

                valid_eval = valid_naive_reward1

                if best_eval < valid_eval:
                    print("We find the new best model")
                    best_eval = valid_eval
                    torch.save({'epoch':epoch,
                                'iters':n_iter,
                                'model':model,
                                'optimizer':optimizer,
                                }, args.model_path + '.best.pth')
                    manager.n_patience = 0
                else:
                    early_stop, optimizer = manager.patience_step(optimizer)
            skip_iters = False
    return train_log, valid_log

