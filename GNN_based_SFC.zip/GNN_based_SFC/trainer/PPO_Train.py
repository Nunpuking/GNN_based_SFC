import neptune
import time
import random
import numpy as np
import copy

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.autograd import Variable

from trainer.RL_utils import ActionSample, ComputeRewards
from data.BatchGenerator import MakeEncodingBatch, MakeDecodingBatch, MakeLabelBatch,\
                                CheckPossibility
from utils.TopologyUpdater import SetTopology, UpdateGenerations, UpdateCapacities,\
                                     MakeTDset, RandomTopology, RandomDeployment
from utils.util_heo import open_log, training_manager, weights_initializer, timeSince
from models.model import Call_Model
from tester.RL_Test import RL_test_main2 as RL_test_main

from collections import deque, namedtuple


# This code is referenced by pytorch tutorial of DQN
Transition = namedtuple('Transition',
                        ('state', 'action', 'action_logprob', 'reward', 'is_terminal'))

class ReplayMemory(object):

    def __init__(self, capacity):
        self.memory = deque([],maxlen=capacity)

    def push(self, *args):
        """Save a transition"""
        self.memory.append(Transition(*args))

    def sample(self, batch_size):
        return random.sample(self.memory, batch_size)

    def __len__(self):
        return len(self.memory)


def PPO_update(TDset, memory, model, optimizer, discount_factor, epoch_run, eps_clip, device):
    B = len(memory)

    softmax = nn.Softmax(dim=1)
    MSE_loss = nn.MSELoss(reduction='none')

    # Load memory
    batch = Transition(*zip(*memory.memory))

    annotation_batch = torch.cat([s[0] for s in batch.state])
    A_out_batch = torch.cat([s[1] for s in batch.state])
    A_in_batch = torch.cat([s[2] for s in batch.state])
    from_node_batch = torch.cat([s[3] for s in batch.state])
    vnf_now_batch = torch.cat([s[4] for s in batch.state])
    vnf_all_batch = torch.cat([s[5] for s in batch.state])
    logit_mask_batch = torch.cat([s[6] for s in batch.state])
    hidden_batch = torch.cat([s[7] for s in batch.state])

    node_action_batch = torch.cat([s for (s, _) in batch.action])
    vnf_action_batch = torch.cat([s for (_, s) in batch.action])
    reward_batch = torch.cat(batch.reward)

    action_logprob_batch = torch.cat(batch.action_logprob)

    is_terminal_batch = torch.cat(batch.is_terminal)

    # Compute returns
    returns = None
    n_transitions = len(memory.memory)
    
    R = np.zeros((B,1))
    for i in range(n_transitions)[::-1]:
        reward = reward_batch[i]
        is_terminal = is_terminal_batch[i]
        if is_terminal:
            R = np.zeros((B,1))
        R = reward + discount_factor*R
        returns = R if returns is None else np.concatenate((R, returns),1)

    for b in range(B):
        print(returns[b])
        returns[b] = (returns[b] - np.mean(returns[b])) / (np.std(returns[b]) + 1e-8)
    returns = Variable(torch.from_numpy(returns)).to(device)

    # Run epochs
    total_loss = 0
    total_actor_loss = 0
    total_critic_loss = 0

    for _ in range(epoch_run):
        # Encoding Stage
        enc_out = model.encoder(annotation_batch, A_out_batch, A_in_batch)

        # Decoding Stage
        state_value = model.run_critic(enc_out, from_node_batch,\
                                vnf_now_batch, vnf_all_batch, logit_mask_batch, hidden_batch)
        
        node_logits, vnf_logits, _ = model(enc_out, from_node_batch,\
                                vnf_now_batch, vnf_all_batch, logit_mask_batch, hidden_batch)
        
        # Compute action_logprob
        node_probs = softmax(node_logits)
        vnf_logits = torch.cat([vnf_logits[i,a,:] for i, a in\
                                 enumerate(node_action_batch)]).reshape(B, 2)
        vnf_probs = softmax(vnf_logits)

        action_logprob = torch.cat([torch.log(node_probs[i, node_action_batch[i]] *\
                              vnf_probs[i, vnf_action_batch[i]]).unsqueeze(0) for i in range(B)])

        # Importance ratio : p/q
        ratios = torch.exp(action_logprob - action_logprob_batch.detach())

        # Advantages
        advantages = returns - state_value.detach()

        # Actor loss using Surrogate loss
        surr1 = ratios * advantages
        surr2 = torch.clamp(ratios, 1-eps_clip, 1+eps_clip) * advantages
        actor_loss = -torch.min(surr1, surr2).mean()

        # Critic loss (No entropy regularization..)
        critic_loss = 0.5*MSE_loss(returns, state_value).mean()

        # Total loss
        train_loss = actor_loss + critic_loss

        train_loss.backward()
        #nn.utils.clip_grad_norm(model.parameters(), 2)
        optimizer.step()
        optimizer.zero_grad()

        total_actor_loss = actor_loss.item() / epoch_run
        total_critic_loss = critic_loss.item() / epoch_run
        total_loss += train_loss.item() / epoch_run

    return total_loss, total_actor_loss, total_critic_loss



def PPO_run(TDset, B, old_model, data_spec, predict_mode, device, max_gen,\
                     epsilon, delay_coeff, consider_maxlat, abs_adj, ppo_update_iters,\
                    discount_factor, ppo_epoch_run, ppo_eps_clip, optimizer, model):
    '''
    B is the batch_size
    N is the number of nodes in the topology

    - INPUT
    TDset           : <B> class TD, TopologyDrivers which is already set 
                               with requests, deployments, and labels
    B               : int
    data_spec       : { 'max_reqs'         : MR,
                        'max_depls'        : MD,
                        'max_labels'       : ML,
                        'n_req_features'   : FR,
                        'n_depl_features'  : FD,
                        'n_label_features' : FL }
    predict_mode    : str          , 'NodeLevel' or 'VNFLevel'
    device          : str          , device that the model is running on
    max_gen         : int          , maximum generation step
    epsilon         : float        , probability for exploration
    delay_coeff     : float        , the controlling parameter of delay reward
    discount_factor : float        , discount factor for computaton of returns

    '''

    memory = ReplayMemory(10000)

    old_model.eval()

    N = TDset[0].max_nodes

    total_reward = 0
    total_loss = 0
    total_actor_loss = 0
    total_critic_loss = 0
    total_n_updates = 0
    n_reqs = 0
    update_iters = 0
    for r_step in range(data_spec['max_reqs']):
        annotation, A_out, A_in, enc_mask, training_flag = MakeEncodingBatch(TDset, r_step, B,\
                                                            abs_adj=abs_adj, node_padding=True)
        if training_flag == False:
            break

        n_reqs += np.sum(enc_mask)

        # Encoding Stage
        enc_out = old_model.encoder(annotation, A_out, A_in)

        # Decoding Stage
        _, E = enc_out.shape
        hidden = torch.zeros([B*N, 2*E])
        from_node, vnf_now, vnf_all, dec_mask, training_flag\
                                    = MakeDecodingBatch(TDset, r_step, predict_mode, B,\
                                                        node_padding=True)
        mask = enc_mask.reshape(B,1)*dec_mask
        logit_mask = mask.reshape(B*N)
        for gen_step in range(max_gen):
            state = (torch.from_numpy(annotation),\
                    torch.from_numpy(A_out),\
                    torch.from_numpy(A_in),\
                    torch.tensor(from_node),\
                    torch.from_numpy(vnf_now),\
                    torch.from_numpy(vnf_all),\
                    torch.from_numpy(logit_mask),\
                    hidden.cpu())

            sample_mask = [1 if sum(vals) > 0 else 0 for vals in mask]

            # Run decoder
            node_logits, vnf_logits, hidden = old_model(enc_out, from_node,\
                                                    vnf_now, vnf_all, logit_mask, hidden)

            # Choose actions
            action_logprob, node_action, vnf_action =\
                                ActionSample(node_logits, vnf_logits, mask, epsilon, B)


            # Update Generations
            if predict_mode == 'NodeLevel':
                UpdateGenerations(TDset, r_step, node_action, B, vnf_action)
            else:
                UpdateGenerations(TDset, r_step, node_action, B, None)

            # Compute Reward
            action_reward = ComputeRewards(TDset, r_step, delay_coeff, reward_mode='REINFORCE', B=B,\
                            consider_maxlat=consider_maxlat) # I used REINFORCE reward for AC too
            action_reward = (sample_mask*action_reward).reshape(B,1) # B, 1
            total_reward += action_reward

            # Update Environment
            from_node, vnf_now, vnf_all, dec_mask, training_flag\
                                        = MakeDecodingBatch(TDset, r_step, predict_mode, B,\
                                                            node_padding=True)
            mask = enc_mask.reshape(B,1)*dec_mask
            logit_mask = mask.reshape(B*N)

            # Save transitions
            action = (torch.from_numpy(node_action),\
                     torch.from_numpy(vnf_action))
            reward = torch.from_numpy(action_reward)
            action_logprob = action_logprob
            if training_flag == True:
                is_terminal = torch.tensor(True).unsqueeze(0)
                memory.push(state, action, action_logprob, reward, is_terminal)
            else:
                is_terminal = torch.tensor(False).unsqueeze(0)
                memory.push(state, action, action_logprob, reward, is_terminal)
                break

        # Update model
        if update_iters >= ppo_update_iters:
            loss, actor_loss, critic_loss = \
                        PPO_update(TDset, memory, model, optimizer, discount_factor,\
                                    ppo_epoch_run, ppo_eps_clip, device)

            old_model.load_state_dict(model.state_dict())

            memory = ReplayMemory(10000)

            total_loss += loss
            total_actor_loss += actor_loss
            total_critic_loss += critic_loss
            total_n_updates += 1

            update_iters = 0
        else:
            update_iters += 1

        # Update Capacities
        UpdateCapacities(TDset, r_step, B)

    if len(memory) > 0:
        # Update model
        loss, actor_loss, critic_loss = \
                    PPO_update(TDset, memory, model, optimizer, discount_factor,\
                                ppo_epoch_run, ppo_eps_clip, device)

        old_model.load_state_dict(model.state_dict())

        memory = ReplayMemory(10000)

        total_loss += loss
        total_actor_loss += actor_loss
        total_critic_loss += critic_loss
        total_n_updates += 1

    return total_reward, total_loss, total_actor_loss, total_critic_loss, total_n_updates, n_reqs


def PPO_train_main(args, trainset, validset, neptune_log_names, checkpoint=None):
    print("-----Training Start-----")
    open_log(args.save_dir, dir=True, message="result_dir")
    open_log(args.save_subdir, dir=True, message="subdir")
    train_log = open_log(args.train_log_path, message="train")
    valid_log = open_log(args.valid_log_path, message="valid")

    train_log.write("{}\t{}\t{}\t{}\t{}\t{}\n".format('Iters', 'Loss', 'ActorLoss', 'CriticLoss',\
                     'Reward', 'Time'))
    valid_log.write("{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\n".format('Iters',\
    'ORGTEST_Fail', 'ORGTEST_DelayRatio', 'ORGTEST_Delay', 'ORGTEST_Reward',\
    'ORGTEST_Standard_Reward',\
    'CHANGETEST1_Fail', 'CHANGETEST1_Delay', 'CHANGETEST1_Reward', 'CHANGETEST1_Standard_Reward',\
    'CHANGETEST2_Fail', 'CHANGETEST2_Delay', 'CHANGETEST2_Reward', 'CHANGETEST2_Standard_Reward',\
    'Time'))

    nt_train_loss, nt_train_actor_loss, nt_train_critic_loss, nt_train_reward,\
    nt_valid_fail1, nt_valid_delayratio1, nt_valid_delay1, nt_valid_reward1,\
    nt_valid_standard_reward1,\
    nt_valid_fail2, nt_valid_delay2, nt_valid_reward2, nt_valid_standard_reward2,\
    nt_valid_fail3, nt_valid_delay3, nt_valid_reward3, nt_valid_standard_reward3,\
    = neptune_log_names

    # No LR decay, Early Stopping
    args.patience = 100000
    manager = training_manager(args)

    TDset = MakeTDset(args.batch_size, args.environment, args.predict_mode, args.adj_temperature,\
                        args.recurrent_delay, args.topo_path, args.sfctypes_path,\
                        args.middlebox_path)

    checkpoint_epoch = 0
    skip_iters = False
    if checkpoint is not None:
        print("Model and optimizer are loaded from checkpoint!")
        checkpoint_epoch = checkpoint['epoch']
        checkpoint_iter = checkpoint['iters']
        model = checkpoint['model']
        optimizer = checkpoint['optimizer']
        skip_iters = True
    else:
        model = Call_Model(args, TDset[0].n_vnfs)
        model.apply(weights_initializer)

        print("# of Model parameters : ", sum(p.numel() for p in model.parameters() \
                                         if p.requires_grad ) )

        if args.opt == 'Adam':
            optimizer = optim.Adam(model.parameters(), lr=args.lr)
        elif args.opt == 'RMSprop':
            optimizer = optim.RMSprop(model.parameters(), lr=args.lr)
        elif args.opt == 'Adadelta':
            optimizer = optim.Adadelta(model.parameters(), lr=args.lr)
        elif args.opt == 'SGD':
            optimizer = optim.SGD(model.parameters(), lr=args.lr, momentum=0.9)
    
        old_model = Call_Model(args, TDset[0].n_vnfs)
        old_model.load_state_dict(model.state_dict())

    model.to(args.device)
    old_model.to(args.device)

    #memory = ReplayMemory(10000)

    start_time = time.time()
    print_loss = 0
    print_actor_loss = 0
    print_critic_loss = 0
    print_reward = 0
    print_n_reqs = 0
    print_n_updates = 0
    best_eval = -999999

    n_iters = 0
    print_iters = 0
    valid_iters = 0
    update_iters = 0

    trainset_spec = trainset.dataset.data_spec

    early_stop = False
    for epoch in range(checkpoint_epoch, args.epochs):
        if early_stop is True:
            break
        model.train()

        for n_iter, (requests, deployments, labels) in enumerate(trainset):
            if skip_iters == True and n_iter < checkpoint_iter:
                n_iters += args.batch_size
                continue

            # Collect Transitions
            if args.topology_change_mode == 1:
                RandomTopology(TDset, args.random_topology_dir, args.sfctypes_path,\
                                 args.middlebox_path, args.random_topo_tag)

            current_batch_size = SetTopology(TDset, requests, deployments, labels, trainset_spec,\
                         learning_mode='RL')

            if args.deployment_change_mode == 1:
                RandomDeployment(TDset, current_batch_size, args.random_depl_add)

            reward, loss, actor_loss, critic_loss, n_updates, n_reqs =\
                         PPO_run(TDset, current_batch_size, old_model, trainset_spec,\
                                args.predict_mode, args.device, args.max_gen, args.rl_epsilon,\
                                args.delay_coeff, args.consider_maxlat, args.abs_adj,\
                                args.ppo_update_iters, args.discount_factor, args.ppo_epoch_run,\
                                args.ppo_eps_clip, optimizer, model)

            print_reward += reward
            print_loss += loss
            print_actor_loss += actor_loss
            print_critic_loss += critic_loss
            print_n_updates += n_updates
            print_n_reqs += n_reqs

            print_iters += current_batch_size
            valid_iters += current_batch_size
            n_iters += current_batch_size

            if print_iters >= args.print_iter:
                print_iters -= args.print_iter
        
                avg_loss = float(print_loss/print_n_updates)
                avg_actor_loss = float(print_actor_loss/print_n_updates)
                avg_critic_loss = float(print_critic_loss/print_n_updates)
                avg_reward = float(print_reward/print_n_reqs)
                print_loss = 0
                print_actor_loss = 0
                print_critic_loss = 0
                print_n_updates = 0
                print_reward = 0
                print_n_reqs = 0

                print("ITER/EPOCH {}/{} | LOSS(TOTAL/ACTOR/CRITIC) {:.4f}/{:.4f}/{:.4f} REWARD {:.4f} | BEST {:.4f} | PAT. {} LR_DECAY {} | {}".format(n_iters, epoch, avg_loss, avg_actor_loss, avg_critic_loss, avg_reward, best_eval, manager.n_patience, manager.n_lr_decay, timeSince(start_time)))
                neptune.log_metric(nt_train_loss, avg_loss)
                neptune.log_metric(nt_train_actor_loss, avg_actor_loss)
                neptune.log_metric(nt_train_critic_loss, avg_critic_loss)
                neptune.log_metric(nt_train_reward, avg_reward)

                train_log.write("{}\t{}\t{}\t{}\t{}\t{}\n".format(\
                    n_iter, avg_loss, avg_actor_loss, avg_critic_loss,\
                     avg_reward, timeSince(start_time)))

            if valid_iters >= args.valid_iter:
                valid_iters -= args.valid_iter

                torch.save({'epoch':epoch,
                            'iters':n_iter,
                            'model':model,
                            'optimizer':optimizer,
                            }, args.model_path)
                print("=========================================")
                print("=============Validation Starts===========")
                print(args.save_subdir)

                valid_reward1, valid_fail1, valid_delay1, valid_delayratio1, valid_naive_reward1\
                                    = RL_test_main(args, model, validset,\
                                     topology_change_mode_test = 0, deployment_change_mode_test = 0)
                valid_reward2, valid_fail2, valid_delay2, valid_delayratio2, valid_naive_reward2\
                                    = RL_test_main(args, model, validset,\
                                     topology_change_mode_test = 1, deployment_change_mode_test = 0)
                valid_reward3, valid_fail3, valid_delay3, valid_delayratio3, valid_naive_reward3\
                                    = RL_test_main(args, model, validset,\
                                     topology_change_mode_test = 1, deployment_change_mode_test = 1)

                print("OriginalTest - FAIL : {:.4f} | DELAY : {:.4f} | REWARD : {:.4f} | STANDARD_REWARD : {:.4f}".format(valid_fail1, valid_delayratio1, valid_reward1, valid_naive_reward1))
                print("ChangeTest1 - FAIL : {:.4f} | DELAY : {:.4f} | REWARD : {:.4f} | STANDARD_REWARD : {:.4f}".format(valid_fail2, valid_delayratio2, valid_reward2, valid_naive_reward2))
                print("ChangeTest2 - FAIL : {:.4f} | DELAY : {:.4f} | REWARD : {:.4f} | STANDARD_REWARD : {:.4f}".format(valid_fail3, valid_delayratio3, valid_reward3, valid_naive_reward3))
                print("=========================================")
                neptune.log_metric(nt_valid_fail1, valid_fail1)
                neptune.log_metric(nt_valid_delayratio1, valid_delayratio1)
                neptune.log_metric(nt_valid_delay1, valid_delay1)
                neptune.log_metric(nt_valid_standard_reward1, valid_naive_reward1)
                neptune.log_metric(nt_valid_fail2, valid_fail2)
                neptune.log_metric(nt_valid_delay2, valid_delay2)
                neptune.log_metric(nt_valid_standard_reward2, valid_naive_reward2)
                neptune.log_metric(nt_valid_fail3, valid_fail3)
                neptune.log_metric(nt_valid_delay3, valid_delay3)
                neptune.log_metric(nt_valid_standard_reward3, valid_naive_reward3)
                valid_log.write("{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\n"\
                .format(\
                    n_iters, valid_fail1, valid_delayratio1, valid_delay1, valid_reward1,\
                    valid_naive_reward1,\
                    valid_fail2, valid_delay2, valid_reward2, valid_naive_reward2,\
                    valid_fail3, valid_delay3, valid_reward3, valid_naive_reward3,\
                    timeSince(start_time)))

                #valid_eval = 10*valid_fail + valid_delay
                valid_eval = valid_naive_reward1

                if best_eval < valid_eval:
                    print("We find the new best model")
                    best_eval = valid_eval
                    torch.save({'epoch':epoch,
                                'iters':n_iter,
                                'model':model,
                                'optimizer':optimizer,
                                }, args.model_path + '.best.pth')
                    manager.n_patience = 0
                else:
                    early_stop, optimizer = manager.patience_step(optimizer)
            skip_iters = False
    return train_log, valid_log

