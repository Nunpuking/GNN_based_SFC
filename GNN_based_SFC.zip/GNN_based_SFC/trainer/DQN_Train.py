import neptune
import time
import random
import numpy as np

import torch
import torch.nn as nn
import torch.optim as optim
from torch.autograd import Variable

from trainer.RL_utils import ActionSample, ComputeRewards
from data.BatchGenerator import MakeEncodingBatch, MakeDecodingBatch, MakeLabelBatch,\
                                CheckPossibility
from utils.TopologyUpdater import SetTopology, UpdateGenerations, UpdateCapacities,\
                                     MakeTDset, RandomTopology, RandomDeployment
from utils.util_heo import open_log, training_manager, weights_initializer, timeSince
from models.model import Call_Model
from tester.RL_Test import RL_test_main2 as RL_test_main

from collections import deque, namedtuple

# This code is referenced by pytorch tutorial of DQN
Transition = namedtuple('Transition',
                        ('state', 'action', 'next_state', 'reward'))

class ReplayMemory(object):

    def __init__(self, capacity):
        self.memory = deque([],maxlen=capacity)

    def push(self, *args):
        """Save a transition"""
        self.memory.append(Transition(*args))

    def sample(self, batch_size):
        return random.sample(self.memory, batch_size)

    def __len__(self):
        return len(self.memory)


def Optimization(policy_net, target_net, memory, batch_size, discount_factor, optimizer, device):
    if len(memory) < batch_size:
        return 0

    transitions = memory.sample(batch_size)
    
    batch = Transition(*zip(*transitions))

    non_final_mask = torch.tensor(tuple(map(lambda s: s[0] is not None,
                                            batch.next_state)), device=device, dtype=torch.bool)
    non_final_next_annotations = torch.cat([s[0] for s in batch.next_state if s[0] is not None])
    non_final_next_A_out = torch.cat([s[1] for s in batch.next_state if s[1] is not None])
    non_final_next_A_in = torch.cat([s[2] for s in batch.next_state if s[2] is not None])
    non_final_next_from_node = torch.cat([s[3] for s in batch.next_state if s[3] is not None])
    non_final_next_vnf_now = torch.cat([s[4] for s in batch.next_state if s[4] is not None])
    non_final_next_vnf_all = torch.cat([s[5] for s in batch.next_state if s[5] is not None])
    non_final_next_logit_mask = torch.cat([s[6] for s in batch.next_state if s[6] is not None])
    non_final_next_hidden = torch.cat([s[7] for s in batch.next_state if s[7] is not None])

    annotation_batch = torch.cat([s[0] for s in batch.state])
    A_out_batch = torch.cat([s[1] for s in batch.state])
    A_in_batch = torch.cat([s[2] for s in batch.state])
    from_node_batch = torch.cat([s[3] for s in batch.state])
    vnf_now_batch = torch.cat([s[4] for s in batch.state])
    vnf_all_batch = torch.cat([s[5] for s in batch.state])
    logit_mask_batch = torch.cat([s[6] for s in batch.state])
    hidden_batch = torch.cat([s[7] for s in batch.state])

    node_action_batch = torch.cat([s for (s, _) in batch.action])
    vnf_action_batch = torch.cat([s for (_, s) in batch.action])
    reward_batch = torch.cat(batch.reward)

    hidden_batch = hidden_batch.to(device)
    node_action_batch = node_action_batch.to(device)
    vnf_action_batch = vnf_action_batch.to(device)
    reward_batch = reward_batch.to(device)

    # Compute Current State Q Values through Policy Network
    enc_out = policy_net.encoder(annotation_batch, A_out_batch, A_in_batch)
    state_node_values, state_vnf_values, _ = policy_net(enc_out, from_node_batch, vnf_now_batch,\
                                                vnf_all_batch, logit_mask_batch, hidden_batch)
    state_node_values = state_node_values.gather(1, node_action_batch.unsqueeze(1))
    state_vnf_values = state_vnf_values.reshape(batch_size,-1).gather(1, \
                            (2*node_action_batch + vnf_action_batch).unsqueeze(1))

    # Compute Next State Q Values through Target Network
    next_state_node_values = torch.zeros(batch_size, dtype=torch.double, device=device)
    next_state_vnf_values = torch.zeros(batch_size, dtype=torch.double, device=device)
    tmp_enc_out = target_net.encoder(non_final_next_annotations, non_final_next_A_out,\
                                    non_final_next_A_in)
    tmp_next_state_node_values, tmp_next_state_vnf_values, _ = target_net(tmp_enc_out,\
                non_final_next_from_node, non_final_next_vnf_now, non_final_next_vnf_all,\
                non_final_next_logit_mask, non_final_next_hidden)
    non_final_batch, _ = tmp_next_state_node_values.shape
    next_state_node_values[non_final_mask] = tmp_next_state_node_values.max(1)[0].detach()
    vnf_index = tmp_next_state_node_values.argmax(1).type(torch.long)
    tmp_next_state_vnf_values = torch.cat([tmp_next_state_vnf_values[i,j,:] for i, j in\
          enumerate(vnf_index)]).reshape(non_final_batch, -1)
    next_state_vnf_values[non_final_mask] = tmp_next_state_vnf_values.max(1)[0].detach()

    # Compute Expected Target and Losses
    expected_state_node_values = (next_state_node_values * discount_factor) + reward_batch
    expected_state_vnf_values = (next_state_vnf_values * discount_factor) + reward_batch

    criterion = nn.SmoothL1Loss()
    node_loss = criterion(state_node_values, expected_state_node_values.unsqueeze(1))
    vnf_loss = criterion(state_vnf_values, expected_state_vnf_values.unsqueeze(1))
    loss = node_loss + vnf_loss

    optimizer.zero_grad()
    loss.backward()
    for param in policy_net.parameters():
        param.grad.data.clamp_(-1,1)
    optimizer.step()

    return loss.item()/batch_size


def DQN_train(TDset, B, policy_net, target_net, optimizer, data_spec, predict_mode, device, max_gen,\
                epsilon, delay_coeff, discount_factor, memory, replay_batch_size, consider_maxlat,\
                abs_adj):

    policy_net.train()

    #N = TDset[0].n_nodes
    N = TDset[0].max_nodes

    total_reward = 0
    total_loss = 0
    n_reqs = 0
    n_pred = 0
    for r_step in range(data_spec['max_reqs']):
        annotation, A_out, A_in, enc_mask, training_flag = MakeEncodingBatch(TDset, r_step, B,\
                                                            abs_adj=abs_adj, node_padding=True)

        if training_flag == False:
            break

        n_reqs += np.sum(enc_mask)

        enc_out = policy_net.encoder(annotation, A_out, A_in)

        rewards = None

        _, E = enc_out.shape
        hidden = torch.zeros([B*N, 2*E])
        from_node, vnf_now, vnf_all, dec_mask, training_flag\
                                    = MakeDecodingBatch(TDset, r_step, predict_mode, B,\
                                                        node_padding=True)
        mask = enc_mask.reshape(B,1)*dec_mask
        logit_mask = mask.reshape(B*N)
        for gen_step in range(max_gen):
            # Generate Transitions
            current_state = (torch.from_numpy(annotation),\
                            torch.from_numpy(A_out),\
                            torch.from_numpy(A_in),\
                            torch.tensor(from_node),\
                            torch.from_numpy(vnf_now),\
                            torch.from_numpy(vnf_all),\
                            torch.from_numpy(logit_mask),\
                            hidden.cpu())

            sample_mask = [1 if sum(vals) > 0 else 0 for vals in mask]

            n_pred += sum(sample_mask)

            # Run decoder
            node_logits, vnf_logits, hidden = policy_net(enc_out, from_node,\
                                                    vnf_now, vnf_all, logit_mask, hidden)

            # Choose actions
            action_logprob, node_action, vnf_action =\
                                ActionSample(node_logits, vnf_logits, mask, epsilon, B)

            # Update Generations
            if predict_mode == 'NodeLevel':
                UpdateGenerations(TDset, r_step, node_action, B, vnf_action)
            else:
                UpdateGenerations(TDset, r_step, node_action, B, None)

            reward = ComputeRewards(TDset, r_step, delay_coeff, reward_mode='DQN', B=B,\
                                    consider_maxlat=consider_maxlat)
            reward = (sample_mask*reward).reshape(B,1)
            total_reward += reward

            # Save Transitions
            action = (torch.from_numpy(node_action), torch.from_numpy(vnf_action))
            reward = torch.from_numpy(reward)
            from_node, vnf_now, vnf_all, dec_mask, training_flag\
                                        = MakeDecodingBatch(TDset, r_step, predict_mode, B,\
                                                            node_padding=True)
            if training_flag == False:
                next_state = (None, None, None, None, None, None, None, None)
                memory.push(current_state, action, next_state, reward)
                break

            mask = enc_mask.reshape(B,1)*dec_mask
            logit_mask = mask.reshape(B*N)
            next_state = (torch.from_numpy(annotation),\
                            torch.from_numpy(A_out),\
                            torch.from_numpy(A_in),\
                            torch.tensor(from_node),\
                            torch.from_numpy(vnf_now),\
                            torch.from_numpy(vnf_all),\
                            torch.from_numpy(logit_mask),\
                            hidden.cpu())

            memory.push(current_state, action, next_state, reward)

            loss = Optimization(policy_net, target_net, memory, replay_batch_size, discount_factor,\
                            optimizer, device)

            total_loss += loss

        # Update Capacities
        UpdateCapacities(TDset, r_step, B)

    return total_loss, n_pred, total_reward, n_reqs

def DQN_train_main(args, trainset, validset, neptune_log_names, checkpoint=None):
    print("-----Training Start-----")
    open_log(args.save_dir, dir=True, message="result_dir")
    open_log(args.save_subdir, dir=True, message="subdir")
    train_log = open_log(args.train_log_path, message="train")
    valid_log = open_log(args.valid_log_path, message="valid")

    train_log.write("{}\t{}\t{}\t{}\n".format('Iters', 'Loss', 'Reward', 'Time'))
    valid_log.write("{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\n".format('Iters',\
    'ORGTEST_Fail', 'ORGTEST_DelayRatio', 'ORGTEST_Delay', 'ORGTEST_Reward',\
    'ORGTEST_Standard_Reward',\
    'CHANGETEST1_Fail', 'CHANGETEST1_Delay', 'CHANGETEST1_Reward', 'CHANGETEST1_Standard_Reward',\
    'CHANGETEST2_Fail', 'CHANGETEST2_Delay', 'CHANGETEST2_Reward', 'CHANGETEST2_Standard_Reward',\
    'Time'))

    nt_train_loss, nt_train_reward,\
    nt_valid_fail1, nt_valid_delayratio1, nt_valid_delay1, nt_valid_reward1,\
    nt_valid_standard_reward1,\
    nt_valid_fail2, nt_valid_delay2, nt_valid_reward2, nt_valid_standard_reward2,\
    nt_valid_fail3, nt_valid_delay3, nt_valid_reward3, nt_valid_standard_reward3,\
    = neptune_log_names

    # No LR decay and Early Stopping
    args.patience = 100000
    manager = training_manager(args)

    # TD for policy_net
    TDset = MakeTDset(args.batch_size, args.environment, args.predict_mode, args.adj_temperature,\
                        args.recurrent_delay, args.topo_path, args.sfctypes_path,\
                        args.middlebox_path)

    checkpoint_epoch = 0
    skip_iters = False
    if checkpoint is not None:
        print("Model and optimizer are loaded from checkpoint!")
        checkpoint_epoch = checkpoint['epoch']
        checkpoint_iter = checkpoint['iters']
        policy_net = checkpoint['model']
        target_net = checkpoint['model']
        optimizer = checkpoint['optimizer']
        skip_iters = True

    else:
        policy_net = Call_Model(args, TDset[0].n_vnfs)
        policy_net.apply(weights_initializer)
        target_net = Call_Model(args, TDset[0].n_vnfs)
        target_net.apply(weights_initializer)
        target_net.eval()

        print( sum( p.numel() for p in policy_net.parameters() if p.requires_grad ) )

        if args.opt == 'Adam':
            optimizer = optim.Adam(policy_net.parameters(), lr=args.lr)
        elif args.opt == 'RMSprop':
            optimizer = optim.RMSprop(policy_net.parameters(), lr=args.lr)
        elif args.opt == 'Adadelta':
            optimizer = optim.Adadelta(policy_net.parameters(), lr=args.lr)
        elif args.opt == 'SGD':
            optimizer = optim.SGD(policy_net.parameters(), lr=args.lr, momentum=0.9)

    policy_net.to(args.device)
    target_net.to(args.device)

    memory = ReplayMemory(10000)

    start_time = time.time()

    steps_done = 0

    print_loss = 0
    print_n_pred = 0
    print_reward = 0
    print_n_reqs = 0
    best_eval = -999999

    n_iters = 0
    print_iters = 0
    valid_iters = 0

    trainset_spec = trainset.dataset.data_spec

    for epoch in range(checkpoint_epoch, args.epochs):
        policy_net.train()

        for n_iter, (requests, deployments, labels) in enumerate(trainset):
            # Generate Episodes
            if args.topology_change_mode == 1:
                RandomTopology(TDset, args.random_topology_dir, args.sfctypes_path,\
                                args.middlebox_path, args.random_topo_tag)

            current_batch_size = SetTopology(TDset, requests, deployments, labels, trainset_spec,\
                         learning_mode='RL')

            if args.deployment_change_mode == 1:
                RandomDeployment(TDset, current_batch_size, args.random_depl_add)

            loss, n_pred, reward, n_reqs = DQN_train(TDset, current_batch_size, policy_net,\
                                        target_net, optimizer, trainset_spec,\
                                        args.predict_mode, args.device, args.max_gen,\
                                        args.rl_epsilon, args.delay_coeff, args.discount_factor,\
                                        memory, args.replay_batch_size, args.consider_maxlat,\
                                        args.abs_adj)

            print_loss += loss
            print_n_pred += n_pred
            print_reward += reward
            print_n_reqs += n_reqs

            print_iters += current_batch_size
            valid_iters += current_batch_size
            n_iters += current_batch_size

            if n_iter % args.dqn_target_update == 0:
                target_net.load_state_dict(policy_net.state_dict())

            if print_iters >= args.print_iter:
                print_iters -= args.print_iter

                avg_loss = float(print_loss/print_n_pred)
                avg_reward = float(print_reward/print_n_reqs)
                print_loss = 0
                print_n_pred = 0
                print_reward = 0
                print_n_reqs = 0

                print("ITER/EPOCH {}/{} | LOSS {:.4f} REWARD {:.4f} | BEST {:.4f} | PAT. {} LR_DECAY {} | {}".format(n_iters, epoch, avg_loss, avg_reward, best_eval, manager.n_patience,\
                 manager.n_lr_decay, timeSince(start_time)))
                neptune.log_metric(nt_train_loss, avg_loss)
                neptune.log_metric(nt_train_reward, avg_reward)

                train_log.write("{}\t{}\t{}\t{}\n".format(\
                    n_iter, avg_loss, avg_reward, timeSince(start_time)))

            if valid_iters >= args.valid_iter:
                valid_iters -= args.valid_iter

                torch.save({'epoch':epoch,
                            'iters':n_iter,
                            'policy_net':policy_net,
                            'target_net':target_net,
                            'optimizer':optimizer,
                            }, args.model_path)
                print("=========================================")
                print("=============Validation Starts===========")
                print(args.save_subdir)

                valid_reward1, valid_fail1, valid_delay1, valid_delayratio1, valid_naive_reward1\
                                    = RL_test_main(args, policy_net, validset,\
                                     topology_change_mode_test = 0, deployment_change_mode_test = 0)
                valid_reward2, valid_fail2, valid_delay2, valid_delayratio2, valid_naive_reward2\
                                    = RL_test_main(args, policy_net, validset,\
                                     topology_change_mode_test = 1, deployment_change_mode_test = 0)
                valid_reward3, valid_fail3, valid_delay3, valid_delayratio3, valid_naive_reward3\
                                    = RL_test_main(args, policy_net, validset,\
                                     topology_change_mode_test = 1, deployment_change_mode_test = 1)

                print("OriginalTest - FAIL : {:.4f} | DELAY : {:.4f} | REWARD : {:.4f} | STANDARD_REWARD : {:.4f}".format(valid_fail1, valid_delayratio1, valid_reward1, valid_naive_reward1))
                print("ChangeTest1 - FAIL : {:.4f} | DELAY : {:.4f} | REWARD : {:.4f} | STANDARD_REWARD : {:.4f}".format(valid_fail2, valid_delayratio2, valid_reward2, valid_naive_reward2))
                print("ChangeTest2 - FAIL : {:.4f} | DELAY : {:.4f} | REWARD : {:.4f} | STANDARD_REWARD : {:.4f}".format(valid_fail3, valid_delayratio3, valid_reward3, valid_naive_reward3))
                print("=========================================")
                neptune.log_metric(nt_valid_fail1, valid_fail1)
                neptune.log_metric(nt_valid_delayratio1, valid_delayratio1)
                neptune.log_metric(nt_valid_delay1, valid_delay1)
                neptune.log_metric(nt_valid_standard_reward1, valid_naive_reward1)
                neptune.log_metric(nt_valid_fail2, valid_fail2)
                neptune.log_metric(nt_valid_delay2, valid_delay2)
                neptune.log_metric(nt_valid_standard_reward2, valid_naive_reward2)
                neptune.log_metric(nt_valid_fail3, valid_fail3)
                neptune.log_metric(nt_valid_delay3, valid_delay3)
                neptune.log_metric(nt_valid_standard_reward3, valid_naive_reward3)
                valid_log.write("{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\n"\
                .format(\
                    n_iters, valid_fail1, valid_delayratio1, valid_delay1, valid_reward1,\
                    valid_naive_reward1,\
                    valid_fail2, valid_delay2, valid_reward2, valid_naive_reward2,\
                    valid_fail3, valid_delay3, valid_reward3, valid_naive_reward3,\
                    timeSince(start_time)))

                valid_eval = valid_naive_reward1

                if best_eval < valid_eval:
                    print("We find the new best model")
                    best_eval = valid_eval
                    torch.save({'epoch':epoch,
                                'iters':n_iter,
                                'policy_net':policy_net,
                                'target_net':target_net,
                                'optimizer':optimizer,
                                }, args.model_path + '.best.pth')
                    manager.n_patience = 0
                else:
                    early_stop, optimizer = manager.patience_step(optimizer)
            skip_iters = False
    return train_log, valid_log
