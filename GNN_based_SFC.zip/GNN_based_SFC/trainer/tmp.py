def Hello():
    print("Hello")
