import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GATConv
from torch_geometric.data import Data 

class Embedding(nn.Module):
    def __init__(self, input_dim, embedding_dim):
        super().__init__()
        self.param = torch.nn.Parameter(torch.randn(input_dim, embedding_dim))

    def forward(self, x):
        """
        :param x: (bsz, n_nodes, anno_dim)
        :return: (bsz, n_nodes, nodes_dim)
        """
        return torch.matmul(x, self.param)


class Encoder(torch.nn.Module):
    def __init__(self, anno_dim, node_state_dim, n_heads=4, **kwargs):
        super().__init__()
        
        self.node_state_dim = node_state_dim
        self.anno_emb = Embedding(anno_dim, node_state_dim)
        self.conv1 = GATConv(node_state_dim, node_state_dim//n_heads, heads=n_heads)
        self.conv2 = GATConv(node_state_dim, node_state_dim//n_heads, heads=n_heads)

    def forward(self, data, **kwargs):
        """
        :param data: torch_geometric.data.Data or 
        """

        if data.batch is None:
            bsz = 1
        else:  
            bsz = data.num_graphs
        
        x, edge_indices, edge_weight = self.anno_emb(data.x), data.edge_index, data.edge_attr
        x = self.conv1(x, edge_indices, edge_weight)
        x = F.relu(x)
        x = F.dropout(x, training=self.training)

        # bsz*n_nodes, out_dim*n_heads
        x = self.conv2(x, edge_indices, edge_weight)
        
        return x.reshape(bsz, -1, self.node_state_dim)
        