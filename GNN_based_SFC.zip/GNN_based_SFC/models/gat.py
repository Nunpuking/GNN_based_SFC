import torch
import torch.nn.functional as F
from torch_geometric.nn import GATConv
from torch_geometric.data import Data 
from torch_geometric.loader import DataLoader

class Encoder(torch.nn.Module):
    
    def __init__(self, anno_dim, node_state_dim, **kwargs):
        super().__init__()
        self.node_state_dim = node_state_dim
        self.conv1 = GATConv(anno_dim, node_state_dim)
        self.conv2 = GATConv(node_state_dim, node_state_dim)

    def forward(self, data, **kwargs):
        
        if data.batch is None:
            bsz = 1
        else:  
            bsz = data.num_graphs
        
        x, edge_indices, edge_weight = data.x, data.edge_index, data.edge_attr

        x = self.conv1(x, edge_indices, edge_weight)
        x = F.relu(x)
        x = F.dropout(x, training=self.training)
        x = self.conv2(x, edge_indices, edge_weight)
        
        return x.reshape(bsz, -1, self.node_state_dim)
        
