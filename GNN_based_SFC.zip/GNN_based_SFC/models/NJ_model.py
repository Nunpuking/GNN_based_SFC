import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F

from models import gat, gat_mec, ggnn

def Call_Model(args, n_vnfs, topology):
    print("="*100)
    print("/models/sfc_model.py")
    print("Important Note: This is test code for compatible with NJ's AS module")
    print("--------------- Dynamic topology change should not be active")
    print("="*100)
    # Prepare configurations
    anno_dim = n_vnfs + 2

    # Call model
    if args.model_name == 'GG_RNN':
        if args.learning_fashion in ['DQN', 'AC', 'A2C', 'PPO']:
            raise SyntaxError("{} algorithm doesn't need GG_RNN")
        if args.encoder_name == 'ggnn':
            encoder = ggnn.Encoder(anno_dim = anno_dim,\
                                    node_state_dim = args.node_state_dim,\
                                    gru_step=args.GRU_steps)
        elif args.encoder_name == 'gat':
            encoder = gat.Encoder(anno_dim = anno_dim,\
                                    node_state_dim = args.node_state_dim)
        elif args.encoder_name == 'gat_mec':
            encoder = gat_mec.Encoder(anno_dim = anno_dim,\
                                    node_state_dim = args.node_state_dim)
        else:
            SyntaxError("Wrong encoder name {}".format(args.encoder_name))

        model = GG_RNN(\
                    encoder = encoder,\
                    num_nodes = topology.n_nodes,\
                    num_vnfs = n_vnfs,\
                    node_state_dim = args.node_state_dim,\
                    vnf_embedding_dim = args.vnf_dim,\
                    pos_encoding_dim = args.posenc_node_dim )
    else:
        raise SyntaxError("This is test model code for copatibility with NJ's AS module. Other models, except GG_RNN, is not available")
    return model


class GG_RNN(nn.Module):
    """ This is from NJ's modification model of GG_RNN (Heo et al, 2020).      
    
    Attributes
        encoder (nn.Module): pretrained encoder that serves (node features, adjacency) as an input
            and produces node representations as an output. 
        num_nodes (int)
        num_vnfs (int)
        node_state_dim (int): dim. of the node_representation
        vnf_embedding_dim (int): dim. of vnf embedding 
        pos_encoding_dim (int): dim. of positional encoding
        device (torch.device)
    """

    def __init__(self,
                encoder,
                num_nodes, 
                num_vnfs,
                node_state_dim,
                vnf_embedding_dim,
                pos_encoding_dim,
                # gru_step=5,
                # device=None
                ):

        super().__init__()
        
        
        self.n_vnfs = num_vnfs
        self.n_nodes = num_nodes
        

        self.node_state_dim = node_state_dim
        self.vnf_dim = vnf_embedding_dim
        self.anno_dim = num_vnfs + 2 # [vnfs1, vnfs2,...] + [src, dst] 
        self.out_dim = 3 # [node_logit[0], vnf_logits[1:]]
        

        # self.anno_emb = 
        self.vnf_now_emb = Embedding(num_vnfs, vnf_embedding_dim) # Pass
        self.vnf_all_emb = Embedding(num_vnfs, vnf_embedding_dim) # Pass


        self.register_buffer('pos_enc', torch.zeros(num_nodes, pos_encoding_dim), persistent=False)
        self.init_position_encoding(num_nodes, pos_encoding_dim)

        self.encoder = encoder
        self.decoder = Decoder(
                out_dim = self.out_dim,
                node_state_dim=node_state_dim, 
                pos_encoding_dim=pos_encoding_dim, 
                vnf_embedding_dim=vnf_embedding_dim
            )

        # Not in original NJ's model
        self.E = node_state_dim



    def init_position_encoding(self, n_position, emb_dim):
        position_enc = np.array([\
                [pos / np.power(10000, 2*(j // 2) / emb_dim) for j in range(emb_dim)]
                if pos != 0 else np.zeros(emb_dim) for pos in range(n_position)])

        position_enc[1:, 0::2] = np.sin(position_enc[1:, 0::2])
        position_enc[1:, 1::2] = np.cos(position_enc[1:, 1::2])
        self.pos_enc = torch.from_numpy(position_enc).type(torch.FloatTensor)
        
    # encoding in original NJ's modification
    def encoding(self, annotation, A_out, A_in, pooling=False):
        """
        Args: 
            annotation: (bsz, n_nodes, 2+n_vnfs) 
            A_out, A_in: (n_nodes, n_nodes)
        """
        if torch.is_tensor(annotation) == False:
            annotation = torch.from_numpy(annotation).type(torch.float)
        if torch.is_tensor(A_out) == False:
            A_out = torch.from_numpy(A_out).type(torch.float)
        if torch.is_tensor(A_in) == False:
            A_in = torch.from_numpy(A_in).type(torch.float)

        if annotation.device != self.device:
            annotation = annotation.to(self.device)
            A_out = A_out.to(self.device)
            A_in = A_in.to(self.device)

        if len(A_out.shape) == 2 and len(A_in.shape) == 2:
            A_out, A_in = A_out.repeat((A_out.size(0), 1, 1)).type(torch.float), A_in.repeat((A_in.size(0), 1, 1)).type(torch.float)

        
        return self.encoder(annotation, A_out, A_in)


    def forward(self, enc_out, from_node, vnf_now, vnf_all, mask, h=None):
        """
        Args
            enc_out (Tensor) : (bsz*n_nodes, E) encoded representations of nodes
            from_node (Tensor) : (bsz)          int, indexes of current node
            vnf_now (Tensor) : (bsz, n_vnfs)       int, indexes of the VNF type that is focused to process now
            vnf_all (Tensor) : (bsz, n_vnfs)       int, indexes of the VNF types that are in the SFC chain
            mask (Tensor): (bsz*n_nodes)       int, binary mask indicate trainable actions 
            h (Tensor): (bsz*n_nodes, 2*node_state_dim) , previous hidden state

        Returns
            node_logits (Tensor): (bsz, n_nodes) final logits of node actions
            vnf_logits (Tensor): (bsz, n_nodes, 2)  final logits of vnf processing actions
            hidden (Tensor): (bsz, n_nodes, 2*node_state_dim)  current hidden state
        """

        if torch.is_tensor(vnf_now) == False:
            vnf_now = torch.from_numpy(vnf_now)
        if torch.is_tensor(vnf_all) == False:
            vnf_all = torch.from_numpy(vnf_all)
        if torch.is_tensor(mask) == False:
            mask = torch.from_numpy(mask)

        if vnf_now.device != self.device:
            vnf_now = vnf_now.to(self.device)
        if vnf_all.device != self.device:
            vnf_all = vnf_all.to(self.device)
        if h.device != self.device:
            h = h.to(self.device)
        if mask.device != self.device:
            mask = mask.to(self.device)

        if vnf_now.dtype != torch.float32:
            vnf_now = vnf_now.type(torch.float32)
        if vnf_all.dtype != torch.float32:
            vnf_all = vnf_all.type(torch.float32)


        bsz, n_nodes, node_state_dim = enc_out.shape
        enc_out = enc_out.reshape(bsz*n_nodes, -1)
        
        # VNF info Embeddings
        # bsz*n_nodes, vnf_dim
        vnf_all = self.vnf_all_emb(vnf_all).repeat(n_nodes, 1)
        
        # bsz*n_nodes, vnf_dim
        vnf_now = self.vnf_now_emb(vnf_now).repeat(n_nodes, 1)

        # Poisitional Encoding  bsz*n_nodes, pos_enc_dim
        node_pos_enc = self.pos_enc[from_node]
        node_pos_enc = node_pos_enc.repeat(n_nodes, 1)

        # Decoding Layer
        concat_input = torch.cat((enc_out, node_pos_enc, vnf_all, vnf_now), 1)

        if h is None:
            h = torch.zeros([bsz*n_nodes, 2*node_state_dim], device=enc_out.device)
            

        output, hidden = self.decoder(concat_input, h)
        # bsz, n_nodes, n_classes
        output = output.reshape(bsz, n_nodes, -1)

        if len(mask.shape) == 1:
            mask = mask.unsqueeze(0).repeat(bsz, 1).unsqueeze(-1)
        output.masked_fill_(mask.expand_as(output)==0, torch.finfo(output.dtype).min)
        
        
        node_logits = output[..., 0].reshape(bsz, -1)
        vnf_logits = output[..., 1:].reshape(bsz,  n_nodes, -1)

        return node_logits, vnf_logits, hidden


    # def Load_PTmodel(self, pt_model):
    #     self.anno_emb = pt_model.anno_emb
    #     self.GRUcell = pt_model.GRUcell
    #     self.vnf_all_emb = pt_model.vnf_all_emb
    #     self.vnf_now_emb = pt_model.vnf_now_emb
    #     self.decoder_GRUcell = pt_model.decoder_GRUcell
    #     self.decoder_out = pt_model.decoder_out



class Embedding(nn.Module):
    def __init__(self, input_dim, embedding_dim):
        super().__init__()
        self.param = torch.nn.Parameter(torch.randn(input_dim, embedding_dim))

    def forward(self, x):
        """
        :param x: (bsz, n_nodes, anno_dim)
        :return: (bsz, n_nodes, nodes_dim)
        """
        return torch.matmul(x, self.param)

class Decoder(nn.Module):
    def __init__(self, out_dim, node_state_dim, pos_encoding_dim, vnf_embedding_dim):
        # Decoder
        super().__init__()
        # enc_out+ pos_enc + vnf_all + vnf_now 
        self.dec_gru = nn.GRUCell(node_state_dim + pos_encoding_dim + 2*vnf_embedding_dim, 2*node_state_dim)
        self.fc_out = nn.Sequential(\
                    nn.Linear(2*node_state_dim, node_state_dim),\
                    nn.ReLU(True),\
                    nn.Linear(node_state_dim, out_dim))

    def forward(self, input, h):
        hidden = self.dec_gru(input, h)
        output = self.fc_out(hidden)
        
        return output, hidden
        
