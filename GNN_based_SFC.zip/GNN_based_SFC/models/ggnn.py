
import torch
import torch.nn as nn

class Embedding(nn.Module):
    def __init__(self, input_dim, embedding_dim):
        super().__init__()
        # self.param = torch.nn.Parameter(torch.randn(input_dim, embedding_dim, dtype=torch.float))
        self.param = torch.nn.Parameter(torch.randn(input_dim, embedding_dim))

    def forward(self, x):
        """
        :param x: (bsz, n_nodes, anno_dim)
        :return: (bsz, n_nodes, nodes_dim)
        """
        return torch.matmul(x, self.param)


class Encoder(nn.Module):
    def __init__(self, anno_dim, node_state_dim, gru_step, **kwargs):
        super().__init__()
        
        self.gru_step = gru_step

        # Encoder
        self.anno_emb = Embedding(anno_dim, node_state_dim)
        self.enc_gru = nn.GRUCell(2*node_state_dim, node_state_dim, bias=False)


    def forward(self, annotation, A_out, A_in, **kwargs):
        """
        :param annotation: (bsz, n_nodes, 2+n_vnfs) 
        :param A_out, A_in: (bsz, n_nodes, n_nodes)
        """
        bsz, n_nodes, _ = annotation.shape
        # assert n_nodes == annotation.size(1) == self.n_nodes


        A_out = self.make_adjacency_eye(A_out, bsz, n_nodes)
        A_in = self.make_adjacency_eye(A_in, bsz, n_nodes)

        # print(annotation)
        h = self.anno_emb(annotation) # <B*N, E>
        h = h.reshape(bsz*n_nodes, -1)
        
        # GG-NN Layer
        for i in range(self.gru_step):
            a_out = torch.matmul(A_out,h)
            a_in = torch.matmul(A_in,h)
            a = torch.cat((a_out,a_in), dim=-1)
            h = self.enc_gru(a,h)

        enc_out = h # <B*N, E>
        
        return enc_out.view(bsz, n_nodes, -1)

    def make_adjacency_eye(self, adj, bsz, n_nodes):
        """WTF?
        :return EyeAdj: torch.Shape(B*N, B*N)
        """
        EyeAdj = torch.zeros(bsz*n_nodes, bsz*n_nodes, device=adj.device)
        for b in range(bsz):
            EyeAdj[b*n_nodes:(b+1)*n_nodes,b*n_nodes:(b+1)*n_nodes] = adj[b]
        return EyeAdj

