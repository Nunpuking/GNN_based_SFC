import torch
import torch.nn as nn
import numpy as np
from torch.autograd import Variable

def Call_Model(args, n_vnfs):
    # Prepare configurations
    anno_dim = n_vnfs + 2
    
    # Call model
    if args.model_name == 'GG_RNN':
        if args.learning_fashion in ['DQN', 'AC', 'A2C', 'PPO']:
            raise SyntaxError("{} algorithm doesn't need GG_RNN")
        model = GG_RNN(args.max_n_nodes, n_vnfs,\
                        args.node_state_dim, args.GRU_steps, anno_dim, args.posenc_node_dim,\
                        args.vnf_dim, args.device, args.predict_mode)
    elif args.model_name == 'GG_RNN_Q':
        if args.learning_fashion in ['REINFORCE', 'SL', 'AC', 'A2C', 'PPO']:
            raise SyntaxError("{} algorithm doesn't need GG_RNN_Q"\
                                .format(args.learning_fashion))
        model = GG_RNN_Q(args.max_n_nodes, n_vnfs,\
                        args.node_state_dim, args.GRU_steps, anno_dim, args.posenc_node_dim,\
                        args.vnf_dim, args.device, args.predict_mode)
    elif args.model_name == 'GG_RNN_AC':
        if args.learning_fashion in ['REINFORCE', 'SL', 'DQN', 'PPO']:
            raise SyntaxError("{} algorithm doens't need GG_RNN_AC"\
                                .format(args.learning_fashion))
        model = GG_RNN_AC(args.max_n_nodes, n_vnfs,\
                        args.node_state_dim, args.GRU_steps, anno_dim, args.posenc_node_dim,\
                        args.vnf_dim, args.device, args.predict_mode)
    elif args.model_name == 'GG_RNN_PPO':
        if args.learning_fashion in ['REINFORCE', 'SL', 'DQN', 'AC', 'A2C']:
            raise SyntaxError("{} algorithm doens't need GG_RNN_AC"\
                                .format(args.learning_fashion))
        model = GG_RNN_PPO(args.max_n_nodes, n_vnfs,\
                        args.node_state_dim, args.GRU_steps, anno_dim, args.posenc_node_dim,\
                        args.vnf_dim, args.device, args.predict_mode)
    elif args.model_name == 'RNN':
        model = RNN(args.max_n_nodes, n_vnfs,\
                        args.node_state_dim, args.GRU_steps, anno_dim, args.posenc_node_dim,\
                        args.vnf_dim, args.device, args.predict_mode)
    else:
        raise SyntaxError("ERROR: {} is Wrong model name".format(args.model_name)) 
    return model

class Embedding(nn.Module):
    def __init__(self, input_dim, embedding_dim):
        super().__init__()
        self.param = torch.nn.Parameter(torch.randn(input_dim, embedding_dim).type(torch.float))

    def forward(self, x):
        return torch.matmul(x, self.param)

def position_encoding_init(n_position, emb_dim):
    position_enc = np.array([\
            [pos / np.power(10000, 2*(j // 2) / emb_dim) for j in range(emb_dim)]
            if pos != 0 else np.zeros(emb_dim) for pos in range(n_position)])

    position_enc[1:, 0::2] = np.sin(position_enc[1:, 0::2])
    position_enc[1:, 1::2] = np.cos(position_enc[1:, 1::2])
    return torch.from_numpy(position_enc).type(torch.FloatTensor)

class GG_RNN(nn.Module):
    def __init__(self, max_N, V, E, T, anno_dim, node_dim, vnf_dim, device, mode):
        super(GG_RNN, self).__init__()

        '''
        - INPUT
        N             : int, the number of nodes in the topology
        max_N         : int, the maximum number of nodes (it determines position-encoding values)
        V             : int, the number of VNF types in the network

        E             : int, the dimension of a node representation
        T             : int, the number of recurrent steps in GG-NN layer
        anno_dim      : int, the dimension of embedded annotatoin vector in GG-NN layer
        node_dim      : int, the dimension of position-encoding
        vnf_dim       : int, the dimension of embedded VNF info. vector

        device        : str, the name of computing device
        mode          : str, mode of the model 'NodeLevel' or 'VNFLevel'
        '''

        self.A = 3
        self.V = V
        self.T = T
        self.E = E
        self.anno_dim = anno_dim
        self.vnf_dim = vnf_dim
        self.node_dim = node_dim

        self.device = device
        self.mode = mode

        # Encoder
        self.anno_emb = Embedding(anno_dim, E)
        self.GRUcell = nn.GRUCell(2*E, E, bias=False)

        # Decoder
        self.pos_enc = position_encoding_init(max_N, node_dim)
        self.pos_enc = Variable(self.pos_enc).to(device)

        self.vnf_now_emb = Embedding(V, vnf_dim)
        self.vnf_all_emb = Embedding(V, vnf_dim)
        self.decoder_GRUcell = nn.GRUCell(E + node_dim + 2*vnf_dim, 2*E)

        self.decoder_out = nn.Sequential(\
                    nn.Linear(2*E, E),\
                    nn.ReLU(True),\
                    nn.Linear(E, self.A))

        # Probability
        self.softmax = nn.Softmax()
        self.sigmoid = nn.Sigmoid()

    def Adjacency_Eye(self, Adj, B, N):
        EyeAdj = torch.zeros(B*N, B*N)
        for b in range(B):
            EyeAdj[b*N:(b+1)*N,b*N:(b+1)*N] = Adj[b]
        
        return EyeAdj

    def encoder(self, annotation, A_out, A_in):
        '''
        B is the batch size
        N is the number of nodes in the topology
        V is the number of VNF types in the network
        E is the dimension of a node representation
        
        - INPUT
        annotation  : <B, N, 2+V> Array, Annotation matrices in the GG-NN layer
        A_out, A_in : <B, N, N>   Array, Adjacency matrices (out&in directions) in the GG-NN layer
        
        - OUTPUT
        enc_out : <B*N, E> Tensor, encoded representations of nodes

        '''
        B, N, _ = A_out.shape
        self.B = B
        self.N = N

        if torch.is_tensor(annotation) == False:
            annotation = torch.from_numpy(annotation).type(torch.float)
        if torch.is_tensor(A_out) == False:
            A_out = torch.from_numpy(A_out).type(torch.float)
        if torch.is_tensor(A_in) == False:
            A_in = torch.from_numpy(A_in).type(torch.float)

        A_out = self.Adjacency_Eye(A_out, B, N)
        A_in = self.Adjacency_Eye(A_in, B, N)

        annotation = Variable(annotation).type(torch.float).to(self.device)
        A_out = Variable(A_out).type(torch.float).to(self.device)
        A_in = Variable(A_in).type(torch.float).to(self.device)

        annotation = annotation.reshape(B*N, self.anno_dim)

        # Annotation Embedding
        h = self.anno_emb(annotation) # <B*N, E>
       
        # GG-NN Layer
        for i in range(self.T):
            a_out = torch.matmul(A_out,h)
            a_in = torch.matmul(A_in,h)
            a = torch.cat((a_out,a_in), dim=1)
            h = self.GRUcell(a,h)
        enc_out = h # <B*N, E>
        return enc_out

    def forward(self, enc_out, from_node, vnf_now, vnf_all, mask, h=None):
        '''
        B is the batch size
        N is the number of nodes in the topology
        V is the number of VNF types in the network
        E is the dimension of a node representation
        
        - INPUT
        enc_out   : <B*N, E>  Tensor, encoded representations of nodes
        from_node : <B>          int, indexes of current node
        vnf_now   : <B, V>       int, indexes of the VNF type that is focused to process now
        vnf_all   : <B, V>       int, indexes of the VNF types that are in the SFC chain
        mask      : <B*N>        int, binary mask indicate trainable actions
        h         : <B*N, 2E> Tensor, previous hidden state

        - OUTPUT
        node_logits : <B, N>     Tensor, final logits of node actions
        vnf_logits  : <B, N, 2>  Tensor, final logits of vnf processing actions
        hidden      : <B*N, 2E> Tensor, current hidden state
        '''

        if torch.is_tensor(vnf_now) == False:
            vnf_now = torch.from_numpy(vnf_now)
        if torch.is_tensor(vnf_all) == False:
            vnf_all = torch.from_numpy(vnf_all)
        if torch.is_tensor(from_node) == True:
            from_node = from_node.numpy()
        if torch.is_tensor(mask) == True:
            mask = mask.numpy()

        B, _ = vnf_now.shape

        # VNF info Embeddings
        vnf_now = Variable(vnf_now).type(torch.float).to(self.device)
        vnf_all = Variable(vnf_all).type(torch.float).to(self.device)

        vnf_now = self.vnf_now_emb(vnf_now).repeat(1,self.N).reshape(B*self.N, self.vnf_dim)
        vnf_all = self.vnf_all_emb(vnf_all).repeat(1,self.N).reshape(B*self.N, self.vnf_dim)

        # Node encoding
        node_pos_enc = self.pos_enc[from_node].repeat(1,self.N).reshape(B*self.N, self.node_dim)
        
        # Decoding Layer
        concat_input = torch.cat((enc_out, node_pos_enc, vnf_all, vnf_now),1)

        h = Variable(h).to(self.device)

        mask = np.array([1 if val == 1 else 1e10 for val in mask])
        mask = Variable(torch.from_numpy(mask)).to(self.device)

        mask = mask.reshape(B,self.N)
        mask = mask.unsqueeze(2).repeat(1,1,self.A)

        hidden = self.decoder_GRUcell(concat_input, h)
        output = self.decoder_out(hidden)

        output = output.reshape(B,self.N,-1)
        max_values = torch.max(torch.max(output,2).values,1).values.unsqueeze(1)\
                    .repeat(1,self.N*self.A).reshape(B,self.N,-1)

        output -= max_values + 1

        output = (mask*output).reshape(B*self.N,-1)
        output += 1
 
        node_logits = output[:,0].reshape(B, -1)
        vnf_logits = output[:,1:].reshape(B, self.N, -1)
        return node_logits, vnf_logits, hidden

    def Load_PTmodel(self, pt_model):
        self.anno_emb = pt_model.anno_emb
        self.GRUcell = pt_model.GRUcell
        self.vnf_all_emb = pt_model.vnf_all_emb
        self.vnf_now_emb = pt_model.vnf_now_emb
        self.decoder_GRUcell = pt_model.decoder_GRUcell
        self.decoder_out = pt_model.decoder_out

    '''
    def forward(self, Anno, A_out, A_in, vnf_chain, node_now, enc_out=None):
        
        N is the number of nodes in the topology ( = self.n_nodes)
        V is the number of VNF types in the network ( = self.n_vnfs)
        E is the dimension of a node representation
        A is the number of actions
        
        - INPUT
        Anno          : <N, 2+V >    Array, Annotaton matrix in the GG-NN layer
        A_out, A_in   : <N, N >      Array, Adjacency matrices (out&in directions) 
                                            in the GG-NN layer     
        vnf_chain     : int Array         , indexes of the VNF types that are in the SFC chain
        node_now      : int               , index of the current node
        
        (optional)
        vnf_type_nums : { str : int } dict, dictionary for vnf_type(str)-type_num(int) matching
        node_label    : int Array         , indexes of the nodes in the label 
                                            for each node traversing action
        process_label : int Array         , 0(not process) or 1(process) 
                                            for each VNF processing action
        vnf_mask      : <N> int Array     , 0(mask) or 1(non-mask) for each nodes (VNF instances)
                                            only for 'VNF-level' prediction tasks
        enc_out       : <N, E>      Tensor, encoded node representatoins of the current request

        - OUTPUT
        probs : <N, S> Array, probabilities of actions
        

        if enc_out is not None:
            Anno = Variable(torch.from_numpy(Anno).type(torch.long)).to(self.device)
            A_out = Variable(torch.from_numpy(A_out).type(torch.float)).to(self.device)
            A_in = Variable(torch.from_numpy(A_in).type(torch.float)).to(self.device)

            enc_out = self.encoder(Anno, A_out, A_in)

        
        hidden = None

        loss = 0
        corrects = 0

        vnf_all_nums = [vnf_type_nums[vnf_type] for vnf_type in vnf_chain if vnf_type != None]
        gen_vnf_inst = torch.zeros(self.n_vnfs)
        for vnf_type in vnf_chain:
            if vnf_type is None:
                break
            vnf_now_num = vnf_type_nums[vnf_type]
            dec_out, hidden = self.decoder(enc_out, node_now, vnf_now_num, vnf_all_nums, hidden) # <N, 1>

            tmp_mask = vnf_mask[vnf_now_num] # <N, >
            dec_out_max = torch.max(dec_out)
            dec_out = torch.transpose(torch.mul(tmp_mask.unsqueeze(0).T, (dec_out-dec_out_max)),0,1)
            tmp_label = label[vnf_now_num]

            loss += self.criterion(dec_out, tmp_label.unsqueeze(0))
            probs = self.softmax(dec_out)
            #print("dec_out : ", dec_out)
            #print("probs : ", probs)

            pred = torch.argmax(probs).item()

            gen_vnf_inst[vnf_now_num] = pred
            corrects += 1 if pred == tmp_label.item() else 0
            if mode == 'train':
                node_now = tmp_label.item()
            else:
                node_now = pred
        return loss, gen_vnf_inst, corrects
    '''

class GG_RNN_Q(nn.Module):
    def __init__(self, max_N, V, E, T, anno_dim, node_dim, vnf_dim, device, mode):
        super(GG_RNN_Q, self).__init__()

        '''
        - INPUT
        N             : int, the number of nodes in the topology
        max_N         : int, the maximum number of nodes (it determines position-encoding values)
        V             : int, the number of VNF types in the network

        E             : int, the dimension of a node representation
        T             : int, the number of recurrent steps in GG-NN layer
        anno_dim      : int, the dimension of embedded annotatoin vector in GG-NN layer
        node_dim      : int, the dimension of position-encoding
        vnf_dim       : int, the dimension of embedded VNF info. vector

        device        : str, the name of computing device
        mode          : str, mode of the model 'NodeLevel' or 'VNFLevel'
        '''

        self.A = 3
        self.V = V
        self.T = T
        self.E = E
        self.anno_dim = anno_dim
        self.vnf_dim = vnf_dim
        self.node_dim = node_dim

        self.device = device
        self.mode = mode

        # Encoder
        self.anno_emb = Embedding(anno_dim, E)
        self.GRUcell = nn.GRUCell(2*E, E, bias=False)

        # Decoder
        self.pos_enc = position_encoding_init(max_N, node_dim)
        self.pos_enc = Variable(self.pos_enc).to(device)

        self.vnf_now_emb = Embedding(V, vnf_dim)
        self.vnf_all_emb = Embedding(V, vnf_dim)
        self.decoder_GRUcell = nn.GRUCell(E + node_dim + 2*vnf_dim, 2*E)

        self.decoder_out = nn.Sequential(\
                    nn.Linear(2*E, E),\
                    nn.ReLU(True),\
                    nn.Linear(E, self.A))

        # Probability
        self.softmax = nn.Softmax()
        self.sigmoid = nn.Sigmoid()


    def Adjacency_Eye(self, Adj, B, N):
        EyeAdj = torch.zeros(B*N, B*N)
        for b in range(B):
            EyeAdj[b*N:(b+1)*N,b*N:(b+1)*N] = Adj[b]
        
        return EyeAdj

    def encoder(self, annotation, A_out, A_in):
        '''
        B is the batch size
        N is the number of nodes in the topology
        V is the number of VNF types in the network
        E is the dimension of a node representation
        
        - INPUT
        annotation  : <B, N, 2+V> Array, Annotation matrices in the GG-NN layer
        A_out, A_in : <B, N, N>   Array, Adjacency matrices (out&in directions) in the GG-NN layer
        
        - OUTPUT
        enc_out : <B*N, E> Tensor, encoded representations of nodes

        '''
        B, N, _ = A_out.shape
        self.B = B
        self.N = N

        if torch.is_tensor(annotation) == False:
            annotation = torch.from_numpy(annotation).type(torch.float)
        if torch.is_tensor(A_out) == False:
            A_out = torch.from_numpy(A_out).type(torch.float)
        if torch.is_tensor(A_in) == False:
            A_in = torch.from_numpy(A_in).type(torch.float)

        A_out = self.Adjacency_Eye(A_out, B, N)
        A_in = self.Adjacency_Eye(A_in, B, N)

        annotation = Variable(annotation).type(torch.float).to(self.device)
        A_out = Variable(A_out).type(torch.float).to(self.device)
        A_in = Variable(A_in).type(torch.float).to(self.device)

        annotation = annotation.reshape(B*N, self.anno_dim)

        # Annotation Embedding
        h = self.anno_emb(annotation) # <B*N, E>
       
        # GG-NN Layer
        for i in range(self.T):
            a_out = torch.matmul(A_out,h)
            a_in = torch.matmul(A_in,h)
            a = torch.cat((a_out,a_in), dim=1)
            h = self.GRUcell(a,h)
        enc_out = h # <B*N, E>
        return enc_out

    def forward(self, enc_out, from_node, vnf_now, vnf_all, mask, h=None):
        '''
        B is the batch size
        N is the number of nodes in the topology
        V is the number of VNF types in the network
        E is the dimension of a node representation
        
        - INPUT
        enc_out   : <B*N, E>  Tensor, encoded representations of nodes
        from_node : <B>          int, indexes of current node
        vnf_now   : <B, V>       int, indexes of the VNF type that is focused to process now
        vnf_all   : <B, V>       int, indexes of the VNF types that are in the SFC chain
        mask      : <B*N>        int, binary mask indicate trainable actions
        h         : <B*N, 2E> Tensor, previous hidden state

        - OUTPUT
        node_logits : <B, N>     Tensor, final logits of node actions
        vnf_logits  : <B, N, 2>  Tensor, final logits of vnf processing actions
        hidden      : <B*N, 2E> Tensor, current hidden state
        '''

        if torch.is_tensor(vnf_now) == False:
            vnf_now = torch.from_numpy(vnf_now)
        if torch.is_tensor(vnf_all) == False:
            vnf_all = torch.from_numpy(vnf_all)
        if torch.is_tensor(from_node) == True:
            from_node = from_node.numpy()
        if torch.is_tensor(mask) == True:
            mask = mask.numpy()

        B, _ = vnf_now.shape

        # VNF info Embeddings
        vnf_now = Variable(vnf_now).type(torch.float).to(self.device)
        vnf_all = Variable(vnf_all).type(torch.float).to(self.device)

        vnf_now = self.vnf_now_emb(vnf_now).repeat(1,self.N).reshape(B*self.N, self.vnf_dim)
        vnf_all = self.vnf_all_emb(vnf_all).repeat(1,self.N).reshape(B*self.N, self.vnf_dim)

        # Node encoding
        node_pos_enc = self.pos_enc[from_node].repeat(1,self.N).reshape(B*self.N, self.node_dim)
        
        # Decoding Layer
        concat_input = torch.cat((enc_out, node_pos_enc, vnf_all, vnf_now),1)

        h = Variable(h).to(self.device)

        mask = np.array([0 if val == 1 else -1e10 for val in mask])
        mask = Variable(torch.from_numpy(mask)).to(self.device)

        mask = mask.reshape(B,self.N)
        mask = mask.unsqueeze(2).repeat(1,1,self.A)

        hidden = self.decoder_GRUcell(concat_input, h)
        output = self.decoder_out(hidden)

        output = output.reshape(B,self.N,-1)
        #max_values = torch.max(torch.max(output,2).values,1).values.unsqueeze(1)\
        #            .repeat(1,self.N*self.A).reshape(B,self.N,-1)

        #output -= max_values + 1

        #output = (mask*output).reshape(B*self.N,-1)
        output = (output + mask).reshape(B*self.N,-1)
        #output += 1
 
        node_logits = output[:,0].reshape(B, -1)
        vnf_logits = output[:,1:].reshape(B, self.N, -1)
        return node_logits, vnf_logits, hidden

    def Load_PTmodel(self, pt_model):
        self.anno_emb = pt_model.anno_emb
        self.GRUcell = pt_model.GRUcell
        self.vnf_all_emb = pt_model.vnf_all_emb
        self.vnf_now_emb = pt_model.vnf_now_emb
        self.decoder_GRUcell = pt_model.decoder_GRUcell
        self.decoder_out = pt_model.decoder_out

class RNN(nn.Module):
    def __init__(self, max_N, V, E, T, anno_dim, node_dim, vnf_dim, device, mode):
        super(RNN, self).__init__()

        '''
        - INPUT
        N             : int, the number of nodes in the topology
        max_N         : int, the maximum number of nodes (it determines position-encoding values)
        V             : int, the number of VNF types in the network

        E             : int, the dimension of a node representation
        T             : int, the number of recurrent steps in GG-NN layer
        anno_dim      : int, the dimension of embedded annotatoin vector in GG-NN layer
        node_dim      : int, the dimension of position-encoding
        vnf_dim       : int, the dimension of embedded VNF info. vector

        device        : str, the name of computing device
        mode          : str, mode of the model 'NodeLevel' or 'VNFLevel'
        '''

        self.A = 3
        self.max_N = max_N
        self.V = V
        self.T = T
        self.E = E
        self.anno_dim = anno_dim
        self.vnf_dim = vnf_dim
        self.node_dim = node_dim

        self.device = device
        self.mode = mode

        # Encoder
        self.anno_emb = Embedding(anno_dim, E)
        #self.GRUcell = nn.GRUCell(2*E, E, bias=False)

        # Decoder
        self.pos_enc = position_encoding_init(max_N, node_dim)
        self.pos_enc = Variable(self.pos_enc).to(device)

        self.vnf_now_emb = Embedding(V, vnf_dim)
        self.vnf_all_emb = Embedding(V, vnf_dim)
        self.decoder_GRUcell = nn.GRUCell(E + 2*(max_N*max_N) + node_dim + 2*vnf_dim, 2*E)

        self.decoder_out = nn.Sequential(\
                    nn.Linear(2*E, E),\
                    nn.ReLU(True),\
                    nn.Linear(E, self.A))

        # Probability
        self.softmax = nn.Softmax()
        self.sigmoid = nn.Sigmoid()


    def Adjacency_Eye(self, Adj, B, N):
        EyeAdj = torch.zeros(B*N, B*N)
        for b in range(B):
            EyeAdj[b*N:(b+1)*N,b*N:(b+1)*N] = Adj[b]

        return EyeAdj

    def encoder(self, annotation, A_out, A_in):
        '''
        B is the batch size
        N is the number of nodes in the topology
        V is the number of VNF types in the network
        E is the dimension of a node representation
        
        - INPUT
        annotation  : <B, N, 2+V> Array, Annotation matrices in the GG-NN layer
        A_out, A_in : <B, N, N>   Array, Adjacency matrices (out&in directions) in the GG-NN layer
        
        - OUTPUT
        enc_out : <B*N, E> Tensor, encoded representations of nodes

        '''
        B, N, _ = A_out.shape
        self.B = B
        self.N = N

        if torch.is_tensor(annotation) == False:
            annotation = torch.from_numpy(annotation).type(torch.float)
        if torch.is_tensor(A_out) == False:
            A_out = torch.from_numpy(A_out).type(torch.float)
        if torch.is_tensor(A_in) == False:
            A_in = torch.from_numpy(A_in).type(torch.float)

        A_out = self.Adjacency_Eye(A_out, B, N)
        A_in = self.Adjacency_Eye(A_in, B, N)

        annotation = Variable(annotation).type(torch.float).to(self.device)
        A_out = Variable(A_out).type(torch.float).to(self.device)
        A_in = Variable(A_in).type(torch.float).to(self.device)

        annotation = annotation.reshape(B*N, self.anno_dim)

        Anno_emb = self.anno_emb(annotation) # <N, E>
        A_out = A_out.view(-1).repeat(self.N,1)
        A_in = A_in.view(-1).repeat(self.N,1)
        enc_out = torch.cat((Anno_emb, A_out, A_in), 1)
        return enc_out
    
    def forward(self, enc_out, from_node, vnf_now, vnf_all, mask, h=None):
        '''
        B is the batch size
        N is the number of nodes in the topology
        V is the number of VNF types in the network
        E is the dimension of a node representation
        
        - INPUT
        enc_out   : <B*N, E>  Tensor, encoded representations of nodes
        from_node : <B>          int, indexes of current node
        vnf_now   : <B, V>       int, indexes of the VNF type that is focused to process now
        vnf_all   : <B, V>       int, indexes of the VNF types that are in the SFC chain
        mask      : <B*N>        int, binary mask indicate trainable actions
        h         : <B*N, 2E> Tensor, previous hidden state

        - OUTPUT
        node_logits : <B, N>     Tensor, final logits of node actions
        vnf_logits  : <B, N, 2>  Tensor, final logits of vnf processing actions
        hidden      : <B*N, 2E> Tensor, current hidden state
        '''

        if torch.is_tensor(vnf_now) == False:
            vnf_now = torch.from_numpy(vnf_now)
        if torch.is_tensor(vnf_all) == False:
            vnf_all = torch.from_numpy(vnf_all)
        if torch.is_tensor(from_node) == True:
            from_node = from_node.numpy()
        if torch.is_tensor(mask) == True:
            mask = mask.numpy()

        B, _ = vnf_now.shape

        # VNF info Embeddings
        vnf_now = Variable(vnf_now).type(torch.float).to(self.device)
        vnf_all = Variable(vnf_all).type(torch.float).to(self.device)

        vnf_now = self.vnf_now_emb(vnf_now).repeat(1,self.N).reshape(B*self.N, self.vnf_dim)
        vnf_all = self.vnf_all_emb(vnf_all).repeat(1,self.N).reshape(B*self.N, self.vnf_dim)

        # Node encoding
        node_pos_enc = self.pos_enc[from_node].repeat(1,self.N).reshape(B*self.N, self.node_dim)
        
        # Decoding Layer
        concat_input = torch.cat((enc_out, node_pos_enc, vnf_all, vnf_now),1)

        h = Variable(h).to(self.device)

        mask = np.array([1 if val == 1 else 1e10 for val in mask])
        mask = Variable(torch.from_numpy(mask)).to(self.device)

        mask = mask.reshape(B,self.N)
        mask = mask.unsqueeze(2).repeat(1,1,self.A)

        hidden = self.decoder_GRUcell(concat_input, h)
        output = self.decoder_out(hidden)

        output = output.reshape(B,self.N,-1)
        max_values = torch.max(torch.max(output,2).values,1).values.unsqueeze(1)\
                    .repeat(1,self.N*self.A).reshape(B,self.N,-1)

        output -= max_values + 1

        output = (mask*output).reshape(B*self.N,-1)
        output += 1
 
        node_logits = output[:,0].reshape(B, -1)
        vnf_logits = output[:,1:].reshape(B, self.N, -1)
        return node_logits, vnf_logits, hidden

    def Load_PTmodel(self, pt_model):
        self.anno_emb = pt_model.anno_emb
        self.vnf_all_emb = pt_model.vnf_all_emb
        self.vnf_now_emb = pt_model.vnf_now_emb
        self.decoder_GRUcell = pt_model.decoder_GRUcell
        self.decoder_out = pt_model.decoder_out

class GG_RNN_AC(nn.Module):
    def __init__(self, max_N, V, E, T, anno_dim, node_dim, vnf_dim, device, mode):
        super(GG_RNN_AC, self).__init__()

        '''
        - INPUT
        N             : int, the number of nodes in the topology
        max_N         : int, the maximum number of nodes (it determines position-encoding values)
        V             : int, the number of VNF types in the network

        E             : int, the dimension of a node representation
        T             : int, the number of recurrent steps in GG-NN layer
        anno_dim      : int, the dimension of embedded annotatoin vector in GG-NN layer
        node_dim      : int, the dimension of position-encoding
        vnf_dim       : int, the dimension of embedded VNF info. vector

        device        : str, the name of computing device
        mode          : str, mode of the model 'NodeLevel' or 'VNFLevel'
        '''

        self.A = 3
        self.V = V
        self.T = T
        self.E = E
        self.anno_dim = anno_dim
        self.vnf_dim = vnf_dim
        self.node_dim = node_dim

        self.device = device
        self.mode = mode

        # Encoder
        self.anno_emb = Embedding(anno_dim, E)
        self.GRUcell = nn.GRUCell(2*E, E, bias=False)

        # Decoder
        self.pos_enc = position_encoding_init(max_N, node_dim)
        self.pos_enc = Variable(self.pos_enc).to(device)

        self.vnf_now_emb = Embedding(V, vnf_dim)
        self.vnf_all_emb = Embedding(V, vnf_dim)
        self.decoder_GRUcell = nn.GRUCell(E + node_dim + 2*vnf_dim, 2*E)

        self.decoder_out = nn.Sequential(\
                    nn.Linear(2*E, E),\
                    nn.ReLU(True),\
                    nn.Linear(E, self.A))

        self.decoder_value_out = nn.Sequential(\
                    nn.Linear(2*E, E),\
                    nn.ReLU(True),\
                    nn.Linear(E, 1))

        # Probability
        self.softmax = nn.Softmax()
        self.sigmoid = nn.Sigmoid()

    def Adjacency_Eye(self, Adj, B, N):
        EyeAdj = torch.zeros(B*N, B*N)
        for b in range(B):
            EyeAdj[b*N:(b+1)*N,b*N:(b+1)*N] = Adj[b]
        
        return EyeAdj

    def encoder(self, annotation, A_out, A_in):
        '''
        B is the batch size
        N is the number of nodes in the topology
        V is the number of VNF types in the network
        E is the dimension of a node representation
        
        - INPUT
        annotation  : <B, N, 2+V> Array, Annotation matrices in the GG-NN layer
        A_out, A_in : <B, N, N>   Array, Adjacency matrices (out&in directions) in the GG-NN layer
        
        - OUTPUT
        enc_out : <B*N, E> Tensor, encoded representations of nodes

        '''
        B, N, _ = A_out.shape
        self.B = B
        self.N = N

        if torch.is_tensor(annotation) == False:
            annotation = torch.from_numpy(annotation).type(torch.float)
        if torch.is_tensor(A_out) == False:
            A_out = torch.from_numpy(A_out).type(torch.float)
        if torch.is_tensor(A_in) == False:
            A_in = torch.from_numpy(A_in).type(torch.float)

        A_out = self.Adjacency_Eye(A_out, B, N)
        A_in = self.Adjacency_Eye(A_in, B, N)

        annotation = Variable(annotation).type(torch.float).to(self.device)
        A_out = Variable(A_out).type(torch.float).to(self.device)
        A_in = Variable(A_in).type(torch.float).to(self.device)

        annotation = annotation.reshape(B*N, self.anno_dim)

        # Annotation Embedding
        h = self.anno_emb(annotation) # <B*N, E>
       
        # GG-NN Layer
        for i in range(self.T):
            a_out = torch.matmul(A_out,h)
            a_in = torch.matmul(A_in,h)
            a = torch.cat((a_out,a_in), dim=1)
            h = self.GRUcell(a,h)
        enc_out = h # <B*N, E>
        return enc_out

    def forward(self, enc_out, from_node, vnf_now, vnf_all, mask, h=None):
        # This is function of actor (policy)

        '''
        B is the batch size
        N is the number of nodes in the topology
        V is the number of VNF types in the network
        E is the dimension of a node representation
        
        - INPUT
        enc_out   : <B*N, E>  Tensor, encoded representations of nodes
        from_node : <B>          int, indexes of current node
        vnf_now   : <B, V>       int, indexes of the VNF type that is focused to process now
        vnf_all   : <B, V>       int, indexes of the VNF types that are in the SFC chain
        mask      : <B*N>        int, binary mask indicate trainable actions
        h         : <B*N, 2E> Tensor, previous hidden state

        - OUTPUT
        node_logits : <B, N>     Tensor, final logits of node actions
        vnf_logits  : <B, N, 2>  Tensor, final logits of vnf processing actions
        hidden      : <B*N, 2E> Tensor, current hidden state
        '''

        if torch.is_tensor(vnf_now) == False:
            vnf_now = torch.from_numpy(vnf_now)
        if torch.is_tensor(vnf_all) == False:
            vnf_all = torch.from_numpy(vnf_all)
        if torch.is_tensor(from_node) == True:
            from_node = from_node.numpy()
        if torch.is_tensor(mask) == True:
            mask = mask.numpy()

        B, _ = vnf_now.shape

        # VNF info Embeddings
        vnf_now = Variable(vnf_now).type(torch.float).to(self.device)
        vnf_all = Variable(vnf_all).type(torch.float).to(self.device)

        vnf_now = self.vnf_now_emb(vnf_now).repeat(1,self.N).reshape(B*self.N, self.vnf_dim)
        vnf_all = self.vnf_all_emb(vnf_all).repeat(1,self.N).reshape(B*self.N, self.vnf_dim)

        # Node encoding
        node_pos_enc = self.pos_enc[from_node].repeat(1,self.N).reshape(B*self.N, self.node_dim)
        
        # Decoding Layer
        concat_input = torch.cat((enc_out, node_pos_enc, vnf_all, vnf_now),1)

        h = Variable(h).to(self.device)

        hidden = self.decoder_GRUcell(concat_input, h)

        # Run Actor
        action_mask = np.array([1 if val == 1 else 1e10 for val in mask])
        action_mask = Variable(torch.from_numpy(action_mask)).to(self.device)

        action_mask = action_mask.reshape(B,self.N)
        action_mask = action_mask.unsqueeze(2).repeat(1,1,self.A)

        action_output = self.decoder_out(hidden)

        action_output = action_output.reshape(B,self.N,-1)
        max_values = torch.max(torch.max(action_output,2).values,1).values.unsqueeze(1)\
                    .repeat(1,self.N*self.A).reshape(B,self.N,-1)

        action_output -= max_values + 1

        action_output = (action_mask*action_output).reshape(B*self.N,-1)
        action_output += 1

        node_logits = action_output[:,0].reshape(B, -1)
        vnf_logits = action_output[:,1:].reshape(B, self.N, -1)

        return node_logits, vnf_logits, hidden

    def run_critic(self, enc_out, from_node, vnf_now, vnf_all, mask, h=None):
        '''
        B is the batch size
        N is the number of nodes in the topology
        V is the number of VNF types in the network
        E is the dimension of a node representation
        
        - INPUT
        enc_out   : <B*N, E>  Tensor, encoded representations of nodes
        from_node : <B>          int, indexes of current node
        vnf_now   : <B, V>       int, indexes of the VNF type that is focused to process now
        vnf_all   : <B, V>       int, indexes of the VNF types that are in the SFC chain
        mask      : <B*N>        int, binary mask indicate trainable actions
        h         : <B*N, 2E> Tensor, previous hidden state

        - OUTPUT
        critic_output : <B>     Tensor, final value of the current state
        '''

        if torch.is_tensor(vnf_now) == False:
            vnf_now = torch.from_numpy(vnf_now)
        if torch.is_tensor(vnf_all) == False:
            vnf_all = torch.from_numpy(vnf_all)
        if torch.is_tensor(from_node) == True:
            from_node = from_node.numpy()
        if torch.is_tensor(mask) == True:
            mask = mask.numpy()

        B, _ = vnf_now.shape

        # VNF info Embeddings
        vnf_now = Variable(vnf_now).type(torch.float).to(self.device)
        vnf_all = Variable(vnf_all).type(torch.float).to(self.device)

        vnf_now = self.vnf_now_emb(vnf_now).repeat(1,self.N).reshape(B*self.N, self.vnf_dim)
        vnf_all = self.vnf_all_emb(vnf_all).repeat(1,self.N).reshape(B*self.N, self.vnf_dim)

        # Node encoding
        node_pos_enc = self.pos_enc[from_node].repeat(1,self.N).reshape(B*self.N, self.node_dim)
        
        # Decoding Layer
        concat_input = torch.cat((enc_out, node_pos_enc, vnf_all, vnf_now),1)

        h = Variable(h).to(self.device)

        hidden = self.decoder_GRUcell(concat_input, h)

        # Run Critic
        critic_mask = Variable(torch.from_numpy(mask)).to(self.device)
        critic_mask = critic_mask.reshape(B,self.N)

        critic_output = self.decoder_value_out(hidden) # B*N, 1

        critic_output = critic_output.reshape(B,self.N)
        critic_output = (critic_mask*critic_output).mean(dim=1)

        return critic_output

    def Load_PTmodel(self, pt_model):
        self.anno_emb = pt_model.anno_emb
        self.GRUcell = pt_model.GRUcell
        self.vnf_all_emb = pt_model.vnf_all_emb
        self.vnf_now_emb = pt_model.vnf_now_emb
        self.decoder_GRUcell = pt_model.decoder_GRUcell
        self.decoder_out = pt_model.decoder_out
        self.decoder_value_out = pt_model.decoder_value_out

class GG_RNN_PPO(nn.Module):
    def __init__(self, max_N, V, E, T, anno_dim, node_dim, vnf_dim, device, mode):
        super(GG_RNN_PPO, self).__init__()

        '''
        - INPUT
        N             : int, the number of nodes in the topology
        max_N         : int, the maximum number of nodes (it determines position-encoding values)
        V             : int, the number of VNF types in the network

        E             : int, the dimension of a node representation
        T             : int, the number of recurrent steps in GG-NN layer
        anno_dim      : int, the dimension of embedded annotatoin vector in GG-NN layer
        node_dim      : int, the dimension of position-encoding
        vnf_dim       : int, the dimension of embedded VNF info. vector

        device        : str, the name of computing device
        mode          : str, mode of the model 'NodeLevel' or 'VNFLevel'
        '''

        self.A = 3
        self.V = V
        self.T = T
        self.E = E
        self.anno_dim = anno_dim
        self.vnf_dim = vnf_dim
        self.node_dim = node_dim

        self.device = device
        self.mode = mode

        # Encoder
        self.anno_emb = Embedding(anno_dim, E)
        self.GRUcell = nn.GRUCell(2*E, E, bias=False)

        # Decoder
        self.pos_enc = position_encoding_init(max_N, node_dim)
        self.pos_enc = Variable(self.pos_enc).to(device)

        self.vnf_now_emb = Embedding(V, vnf_dim)
        self.vnf_all_emb = Embedding(V, vnf_dim)
        self.decoder_GRUcell = nn.GRUCell(E + node_dim + 2*vnf_dim, 2*E)

        self.decoder_out = nn.Sequential(\
                    nn.Linear(2*E, E),\
                    nn.ReLU(True),\
                    nn.Linear(E, self.A))

        self.decoder_value_out = nn.Sequential(\
                    nn.Linear(2*E, E),\
                    nn.ReLU(True),\
                    nn.Linear(E, 1))

        # Probability
        self.softmax = nn.Softmax()
        self.sigmoid = nn.Sigmoid()

    def Adjacency_Eye(self, Adj, B, N):
        EyeAdj = torch.zeros(B*N, B*N)
        for b in range(B):
            EyeAdj[b*N:(b+1)*N,b*N:(b+1)*N] = Adj[b]
        
        return EyeAdj

    def encoder(self, annotation, A_out, A_in):
        '''
        B is the batch size
        N is the number of nodes in the topology
        V is the number of VNF types in the network
        E is the dimension of a node representation
        
        - INPUT
        annotation  : <B, N, 2+V> Array, Annotation matrices in the GG-NN layer
        A_out, A_in : <B, N, N>   Array, Adjacency matrices (out&in directions) in the GG-NN layer
        
        - OUTPUT
        enc_out : <B*N, E> Tensor, encoded representations of nodes

        '''
        B, N, _ = A_out.shape
        self.B = B
        self.N = N

        if torch.is_tensor(annotation) == False:
            annotation = torch.from_numpy(annotation).type(torch.float)
        if torch.is_tensor(A_out) == False:
            A_out = torch.from_numpy(A_out).type(torch.float)
        if torch.is_tensor(A_in) == False:
            A_in = torch.from_numpy(A_in).type(torch.float)

        A_out = self.Adjacency_Eye(A_out, B, N)
        A_in = self.Adjacency_Eye(A_in, B, N)

        annotation = Variable(annotation).type(torch.float).to(self.device)
        A_out = Variable(A_out).type(torch.float).to(self.device)
        A_in = Variable(A_in).type(torch.float).to(self.device)

        annotation = annotation.reshape(B*N, self.anno_dim)

        # Annotation Embedding
        h = self.anno_emb(annotation) # <B*N, E>
       
        # GG-NN Layer
        for i in range(self.T):
            a_out = torch.matmul(A_out,h)
            a_in = torch.matmul(A_in,h)
            a = torch.cat((a_out,a_in), dim=1)
            h = self.GRUcell(a,h)
        enc_out = h # <B*N, E>
        return enc_out

    def forward(self, enc_out, from_node, vnf_now, vnf_all, mask, h=None):
        # This is function of actor (policy)

        '''
        B is the batch size
        N is the number of nodes in the topology
        V is the number of VNF types in the network
        E is the dimension of a node representation
        
        - INPUT
        enc_out   : <B*N, E>  Tensor, encoded representations of nodes
        from_node : <B>          int, indexes of current node
        vnf_now   : <B, V>       int, indexes of the VNF type that is focused to process now
        vnf_all   : <B, V>       int, indexes of the VNF types that are in the SFC chain
        mask      : <B*N>        int, binary mask indicate trainable actions
        h         : <B*N, 2E> Tensor, previous hidden state

        - OUTPUT
        node_logits : <B, N>     Tensor, final logits of node actions
        vnf_logits  : <B, N, 2>  Tensor, final logits of vnf processing actions
        hidden      : <B*N, 2E> Tensor, current hidden state
        '''

        if torch.is_tensor(vnf_now) == False:
            vnf_now = torch.from_numpy(vnf_now)
        if torch.is_tensor(vnf_all) == False:
            vnf_all = torch.from_numpy(vnf_all)
        if torch.is_tensor(from_node) == True:
            from_node = from_node.numpy()
        if torch.is_tensor(mask) == True:
            mask = mask.numpy()

        B, _ = vnf_now.shape

        # VNF info Embeddings
        vnf_now = Variable(vnf_now).type(torch.float).to(self.device)
        vnf_all = Variable(vnf_all).type(torch.float).to(self.device)

        vnf_now = self.vnf_now_emb(vnf_now).repeat(1,self.N).reshape(B*self.N, self.vnf_dim)
        vnf_all = self.vnf_all_emb(vnf_all).repeat(1,self.N).reshape(B*self.N, self.vnf_dim)

        # Node encoding
        node_pos_enc = self.pos_enc[from_node].repeat(1,self.N).reshape(B*self.N, self.node_dim)
        
        # Decoding Layer
        concat_input = torch.cat((enc_out, node_pos_enc, vnf_all, vnf_now),1)

        h = Variable(h).to(self.device)

        hidden = self.decoder_GRUcell(concat_input, h)

        # Run Actor
        action_mask = np.array([1 if val == 1 else -1e10 for val in mask])
        action_mask = Variable(torch.from_numpy(action_mask)).to(self.device)

        action_mask = action_mask.reshape(B,self.N)
        action_mask = action_mask.unsqueeze(2).repeat(1,1,self.A)

        action_output = self.decoder_out(hidden)

        action_output = action_output.reshape(B,self.N,-1)
        #max_values = torch.max(torch.max(action_output,2).values,1).values.unsqueeze(1)\
        #            .repeat(1,self.N*self.A).reshape(B,self.N,-1)

        #action_output -= max_values + 1

        #action_output = (action_mask*action_output).reshape(B*self.N,-1)
        #action_output += 1
        action_output = (action_output + action_mask).reshape(B*self.N,-1)

        node_logits = action_output[:,0].reshape(B, -1)
        vnf_logits = action_output[:,1:].reshape(B, self.N, -1)

        return node_logits, vnf_logits, hidden

    def run_critic(self, enc_out, from_node, vnf_now, vnf_all, mask, h=None):
        '''
        B is the batch size
        N is the number of nodes in the topology
        V is the number of VNF types in the network
        E is the dimension of a node representation
        
        - INPUT
        enc_out   : <B*N, E>  Tensor, encoded representations of nodes
        from_node : <B>          int, indexes of current node
        vnf_now   : <B, V>       int, indexes of the VNF type that is focused to process now
        vnf_all   : <B, V>       int, indexes of the VNF types that are in the SFC chain
        mask      : <B*N>        int, binary mask indicate trainable actions
        h         : <B*N, 2E> Tensor, previous hidden state

        - OUTPUT
        critic_output : <B>     Tensor, final value of the current state
        '''

        if torch.is_tensor(vnf_now) == False:
            vnf_now = torch.from_numpy(vnf_now)
        if torch.is_tensor(vnf_all) == False:
            vnf_all = torch.from_numpy(vnf_all)
        if torch.is_tensor(from_node) == True:
            from_node = from_node.numpy()
        if torch.is_tensor(mask) == True:
            mask = mask.numpy()

        B, _ = vnf_now.shape

        # VNF info Embeddings
        vnf_now = Variable(vnf_now).type(torch.float).to(self.device)
        vnf_all = Variable(vnf_all).type(torch.float).to(self.device)

        vnf_now = self.vnf_now_emb(vnf_now).repeat(1,self.N).reshape(B*self.N, self.vnf_dim)
        vnf_all = self.vnf_all_emb(vnf_all).repeat(1,self.N).reshape(B*self.N, self.vnf_dim)

        # Node encoding
        node_pos_enc = self.pos_enc[from_node].repeat(1,self.N).reshape(B*self.N, self.node_dim)
        
        # Decoding Layer
        concat_input = torch.cat((enc_out, node_pos_enc, vnf_all, vnf_now),1)

        h = Variable(h).to(self.device)

        hidden = self.decoder_GRUcell(concat_input, h)

        # Run Critic
        critic_mask = Variable(torch.from_numpy(mask)).to(self.device)
        critic_mask = critic_mask.reshape(B,self.N)

        critic_output = self.decoder_value_out(hidden) # B*N, 1

        critic_output = critic_output.reshape(B,self.N)
        critic_output = (critic_mask*critic_output).mean(dim=1)

        return critic_output

    def Load_PTmodel(self, pt_model):
        self.anno_emb = pt_model.anno_emb
        self.GRUcell = pt_model.GRUcell
        self.vnf_all_emb = pt_model.vnf_all_emb
        self.vnf_now_emb = pt_model.vnf_now_emb
        self.decoder_GRUcell = pt_model.decoder_GRUcell
        self.decoder_out = pt_model.decoder_out
        self.decoder_value_out = pt_model.decoder_value_out

