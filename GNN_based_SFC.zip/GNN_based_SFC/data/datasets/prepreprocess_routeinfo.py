import numpy as np
import pandas as pd
import os

routeinfo_path = './20230408-routeinfo.csv'
save_path = './20230408-routeinfo_org.csv'

routeinfo_df = pd.read_csv(routeinfo_path, sep=',')
routeinfo_df = routeinfo_df.sort_values(by=['arrivaltime','rid','nf'])

routeinfo_df.to_csv(save_path, index=False)
