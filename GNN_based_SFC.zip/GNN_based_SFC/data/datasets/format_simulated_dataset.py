import pandas as pd
import numpy as np
import copy
import os

raw_req_dataset = './20230408-requests_org.csv'
raw_depl_dataset = './20230408-nodeinfo_org.csv'
raw_route_dataset = './20230408-routeinfo_org.csv'

raw_req_set = np.array(pd.read_csv(raw_req_dataset, skiprows=0))
raw_depl_set = np.array(pd.read_csv(raw_depl_dataset, skiprows=0))
raw_route_set = np.array(pd.read_csv(raw_route_dataset, skiprows=0))

(N_REQS, _) = raw_req_set.shape

print("Collecting arrivaltimes")
arrivaltimes = np.zeros(N_REQS, dtype=int)
active_reqs = {}
tmp_active_reqs = []
for n_req in range(N_REQS):
    arrivaltime, duration, sfcid = raw_req_set[n_req][0], raw_req_set[n_req][1],\
                                   raw_req_set[n_req][-1]
    arrivaltime = int(arrivaltime)
    duration = int(duration)
    sfcid = int(sfcid)

    arrivaltimes[n_req] = arrivaltime

    tmp_active_reqs.append((arrivaltime+duration, sfcid, int(n_req+1)))
    for i, req in reversed(list(enumerate(tmp_active_reqs))):
        (active_time, _, _) = req
        if arrivaltime > active_time:
            tmp_active_reqs.pop(i)
    active_reqs[arrivaltime] = copy.deepcopy(tmp_active_reqs)


print("Processing deployment")
(N_DEPL, _) = raw_depl_set.shape
out_depl_set = copy.deepcopy(raw_depl_set)
for n_depl in range(N_DEPL):
    [idx, node, vnf_type, ninst] = raw_depl_set[n_depl]
    out_depl_set[n_depl] = [arrivaltimes[int(idx)-1], node, vnf_type, ninst]

# Route file needs replace idx2arrivaltime & deleting the last line of each request solution
print("Processing routes")
(N_ROUTE, _) = raw_route_set.shape
out_route_set = copy.deepcopy(raw_route_set)
deleting_idxes = []
prev_arrivaltime = 1
prev_req_id = 1
delete=True
for n_route in range(N_ROUTE):
    print("{}/{} processes..".format(n_route,N_ROUTE), end="\r")
    [idx, req_id, vnf_type, node] = raw_route_set[n_route]
    arrivaltime = arrivaltimes[int(idx)-1]
    out_route_set[n_route] = [arrivaltime, req_id, vnf_type, node]

    if arrivaltime != prev_arrivaltime: # This 'n_route' is the index of new solution
        prev_arrivaltime = arrivaltime
        prev_req_id = 0
        if delete is True:
            deleting_idxes.append(n_route-1)
            delete=False
    if req_id != prev_req_id: # This 'n_route' is the index of new solution
        prev_req_id = req_id
        if delete is True:
            deleting_idxes.append(n_route-1)
            delete=False
    delete=True

out_route_set = np.delete(out_route_set, deleting_idxes, axis=0)

print("Change VNF id of Route file")
sfctypes = [['nat','firewall','ids'],['nat','proxy'],['nat','wano'],\
            ['nat','firewall','wano','ids']]
(N_ROUTE, _) = out_route_set.shape
out_route_set2 = copy.deepcopy(out_route_set).astype(str)
for n_route in range(N_ROUTE):
    print("{}/{} processes..".format(n_route,N_ROUTE), end="\r")
    [arrivaltime, req_id, vnf_num, node] = out_route_set[n_route]
    arrivaltime = int(arrivaltime)
    req_id = int(req_id)
    vnf_num = int(vnf_num)

    tmp_active_req = active_reqs[arrivaltime]
    
    (_, sfcid, org_req_id) = tmp_active_req[req_id-1]
    vnf_type = sfctypes[sfcid-1][vnf_num-1]
    out_route_set2[n_route] = [arrivaltime, org_req_id, vnf_type, node]
out_route_set = out_route_set2

req_save_path = './20230408-requests.csv'
depl_save_path = './20230408-nodeinfo.csv'
route_save_path = './20230408-routeinfo.csv'

req_df = pd.DataFrame(raw_req_set).astype(str)
depl_df = pd.DataFrame(out_depl_set).astype(str)
route_df = pd.DataFrame(out_route_set).astype(str)

if os.path.exists(req_save_path):
    os.remove(req_save_path)
req_df.to_csv(req_save_path, index=False)
if os.path.exists(depl_save_path):
    os.remove(depl_save_path)
depl_df.to_csv(depl_save_path, index=False)
if os.path.exists(route_save_path):
    os.remove(route_save_path)
route_df.to_csv(route_save_path, index=False)

print("Done")
