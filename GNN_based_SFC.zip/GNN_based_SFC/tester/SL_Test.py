import time
import copy

import torch
import torch.nn as nn
from torch.autograd import Variable

from data.BatchGenerator import MakeEncodingBatch, MakeDecodingBatch, MakeLabelBatch
from utils.TopologyUpdater import SetTopology, UpdateGenerations, UpdateCapacities, MakeTDset,\
                                RandomTopology, RandomDeployment

from evaluations.metrics import ComputeFails, ComputeDelayRatios, ComputeDelays, ComputeDelays4Log
from trainer.RL_utils import ComputeNaiveRewards
from models.model import Call_Model

def node_to_edgeset(nodes):
    # testbed topology
    testbed_edgeset = {0: 0,\
                       1: 1,\
                       2: 1,\
                       3: 2,\
                       4: 2,\
                       5: 2,\
                       6: 3,\
                       7: 4,\
                       8: 5,\
                       9: 6,\
                       10: 7,\
                       11: 8,\
                       -1: -1}

    B = len(nodes)

    edges = copy.deepcopy(nodes.clone().detach())
    for b in range(B):
        edges[b] = testbed_edgeset[nodes[b].item()]
    return edges


def SL_test(TDset, B, model, data_spec, predict_mode, device, max_gen, abs_adj):
    '''
    B is the batch_size
    N is the number of nodes in the topology

    - INPUT
    TDset        : <B> class TD   , TopologyDrivers which is already set 
                                  with requests, deployments, and labels
    model        : class model
    data_spec    : { 'max_reqs'         : MR,
                     'max_depls'        : MD,
                     'max_labels'       : ML,
                     'n_req_features'   : FR,
                     'n_depl_features'  : FD,
                     'n_label_features' : FL }
    predict_mode : str            , 'NodeLevel' or 'VNFLevel'
    deivce       : str            , device that the model is running on
    max_gen      : int            , maximum limit of predictions    

    '''

    model.eval()
    softmax = nn.Softmax(dim=1)

    N = TDset[0].n_nodes

    total_n_fail = 0
    total_delayratio = 0
    total_navie_reward = 0

    n_reqs = 0
    for r_step in range(data_spec['max_reqs']):
        annotation, A_out, A_in, enc_mask, testing_flag = MakeEncodingBatch(TDset, r_step, B,\
                                                                            abs_adj=abs_adj)
        if testing_flag == False:
            break

        # Encoding Stage
        enc_out = model.encoder(annotation, A_out, A_in)

        # Decoding Stage
        _, E = enc_out.shape
        hidden = torch.zeros([B*N, 2*E])
        for gen_step in range(max_gen):
            from_node, vnf_now, vnf_all, dec_mask, testing_flag\
                                     = MakeDecodingBatch(TDset, r_step, predict_mode, B)
            if testing_flag == False:
                break

            mask = enc_mask.reshape(B,1)*dec_mask

            logit_mask = mask.reshape(B*N)

            # Run decoder
            node_logits, vnf_logits, hidden = model(enc_out, from_node,\
                                                     vnf_now, vnf_all, logit_mask, hidden)

            node_probs = softmax(node_logits)

            node_pred = torch.argmax(node_probs, dim=1)

            if predict_mode == 'NodeLevel':
                vnf_probs = None
                for b in range(B):
                    tmp_vnf_logit = vnf_logits[b, node_pred[b], :].unsqueeze(0)
                    vnf_probs = tmp_vnf_logit if vnf_probs is None else\
                                torch.cat((vnf_probs, tmp_vnf_logit),0) # <B, 2>
                vnf_probs = softmax(vnf_probs)
                vnf_pred = torch.argmax(vnf_probs, dim=1).cpu().numpy()
            else:
                vnf_pred = None

            # Update Generations
            UpdateGenerations(TDset, r_step, node_pred.cpu().numpy(),\
                                             B, vnf_pred) # Update with generation
        

        # Update Capacities
        UpdateCapacities(TDset, r_step, B)

        tmp_n_reqs, n_fails = ComputeFails(TDset, r_step, B)
        _, delay_ratios = ComputeDelayRatios(TDset, r_step, B)

        n_reqs += tmp_n_reqs
        total_n_fail += n_fails
        total_delayratio += delay_ratios

    return total_n_fail, total_delayratio, n_reqs

def SL_test_main(args, pt_model, testset):
    print("-----Testing Start-----")

    TDset = MakeTDset(args.batch_size, args.environment, args.predict_mode, args.adj_temperature,\
                        args.recurrent_delay, args.topo_path, args.sfctypes_path,\
                        args.middlebox_path)

    model = Call_Model(args, TDset[0].n_vnfs)
    model.to(args.device)

    model.Load_PTmodel(pt_model)

    start_time = time.time()
    test_fail = 0
    test_delay = 0
    n_reqs = 0

    testset_spec = testset.dataset.data_spec

    for i, (requests, deployments, labels) in enumerate(testset):
        if args.topology_change_mode_test == 1:
            RandomTopology(TDset, args.random_topology_test_dir, args.sfctypes_path,\
                        args.middlebox_path, args.random_topo_tag)

        current_batch_size = SetTopology(TDset, requests, deployments, labels, testset_spec,\
                     learning_mode='SL')

        if args.deployment_change_mode_test == 1:
            RandomDeployment(TDset, current_batch_size, args.random_depl_add)

        tmp_fail, tmp_delay, tmp_reqs = SL_test(TDset, current_batch_size,\
                                 model, testset_spec, args.predict_mode, args.device, args.max_gen,\
                                args.abs_adj)

        test_fail += tmp_fail
        test_delay += tmp_delay
        n_reqs += tmp_reqs

    test_fail = float(test_fail / n_reqs)
    test_delay = float(test_delay / n_reqs)

    return test_fail, test_delay

# 2 version is for evaluating 'delay'
def SL_test2(TDset, B, model, data_spec, predict_mode, device, max_gen, abs_adj, delay_log=None):
    '''
    B is the batch_size
    N is the number of nodes in the topology

    - INPUT
    TDset        : <B> class TD   , TopologyDrivers which is already set 
                                  with requests, deployments, and labels
    model        : class model
    data_spec    : { 'max_reqs'         : MR,
                     'max_depls'        : MD,
                     'max_labels'       : ML,
                     'n_req_features'   : FR,
                     'n_depl_features'  : FD,
                     'n_label_features' : FL }
    predict_mode : str            , 'NodeLevel' or 'VNFLevel'
    deivce       : str            , device that the model is running on
    max_gen      : int            , maximum limit of predictions    

    '''

    model.eval()
    softmax = nn.Softmax(dim=1)

    N = TDset[0].n_nodes

    total_n_fail = 0
    total_delay = 0
    total_delayratios = 0
    total_naive_reward = 0
    total_acc = 0
    total_edge_acc = 0
    total_n_acc = 0
    n_reqs = 0
    for r_step in range(data_spec['max_reqs']):
        annotation, A_out, A_in, enc_mask, testing_flag = MakeEncodingBatch(TDset, r_step, B,\
                                                                            abs_adj=abs_adj)
        if testing_flag == False:
            break

        # Encoding Stage
        enc_out = model.encoder(annotation, A_out, A_in)

        # Decoding Stage
        #_, E = enc_out.shape
        hidden = torch.zeros([B*N, 2*model.E])
        for gen_step in range(max_gen):
            from_node, vnf_now, vnf_all, dec_mask, testing_flag\
                                     = MakeDecodingBatch(TDset, r_step, predict_mode, B)
            if testing_flag == False:
                break

            label_node, label_vnf = MakeLabelBatch(TDset, r_step, gen_step, B)
            label_node = Variable(torch.from_numpy(label_node).type(torch.long)).to(device)

            mask = enc_mask.reshape(B,1)*dec_mask

            logit_mask = mask.reshape(B*N)

            # Run decoder
            node_logits, vnf_logits, hidden = model(enc_out, from_node,\
                                                     vnf_now, vnf_all, logit_mask, hidden)

            node_probs = softmax(node_logits)

            node_pred = torch.argmax(node_probs, dim=1)

            for b in range(B):
                if not (torch.abs(torch.max(node_probs[b]) - torch.min(node_probs[b])) > 0.999):
                    total_acc += torch.eq(node_pred, label_node).type(torch.int).item()
                    total_edge_acc += torch.eq(node_to_edgeset(node_pred),\
                                               node_to_edgeset(label_node)).type(torch.int).item()
                    total_n_acc += 1

            if predict_mode == 'NodeLevel':
                vnf_probs = None
                for b in range(B):
                    tmp_vnf_logit = vnf_logits[b, node_pred[b], :].unsqueeze(0)
                    vnf_probs = tmp_vnf_logit if vnf_probs is None else\
                                torch.cat((vnf_probs, tmp_vnf_logit),0) # <B, 2>
                vnf_probs = softmax(vnf_probs)
                vnf_pred = torch.argmax(vnf_probs, dim=1).cpu().numpy()
            else:
                vnf_pred = None

            # Update Generations
            UpdateGenerations(TDset, r_step, node_pred.cpu().numpy(),\
                                             B, vnf_pred) # Update with generation
        

        # Update Capacities
        UpdateCapacities(TDset, r_step, B)

        tmp_n_reqs, n_fails = ComputeFails(TDset, r_step, B)
        _, delay = ComputeDelays(TDset, r_step, B)
        _, delays, maxlats = ComputeDelays4Log(TDset, r_step, B)
        _, delay_ratio = ComputeDelayRatios(TDset, r_step, B)
        naive_reward = ComputeNaiveRewards(TDset, r_step, 1.0, B=B)

        n_reqs += tmp_n_reqs
        total_n_fail += n_fails
        total_delay += delay
        total_delayratios += delay_ratio
        total_naive_reward += naive_reward

        if delay_log is not None:
            for b in range(len(delays)):
                delay_log.write("{}\t{}\n".format(delays[b], maxlats[b]))

    return total_n_fail, total_delay, total_delayratios, total_naive_reward, n_reqs, total_acc, total_edge_acc, total_n_acc

def SL_test_main2(args, pt_model, testset, topology_change_mode_test=0,\
                deployment_change_mode_test=0, delay_log=None):
    print("-----Testing Start-----")
    if delay_log is not None:
        delay_log.write("Delay\tMaxlat\n")

    TDset = MakeTDset(args.batch_size, args.environment, args.predict_mode, args.adj_temperature,\
                        args.recurrent_delay, args.topo_path, args.sfctypes_path,\
                        args.middlebox_path)

    model = Call_Model(args, TDset[0].n_vnfs)
    model.to(args.device)

    model.Load_PTmodel(pt_model)

    start_time = time.time()
    test_fail = 0
    test_delay = 0
    test_delayratio = 0
    test_naive_reward = 0
    test_acc = 0
    test_edge_acc = 0
    test_n_acc = 0
    n_reqs = 0

    testset_spec = testset.dataset.data_spec

    for i, (requests, deployments, labels) in enumerate(testset):

        if topology_change_mode_test == 1:
            RandomTopology(TDset, args.random_topology_test_dir, args.sfctypes_path,\
                        args.middlebox_path, args.random_topo_tag)

        current_batch_size = SetTopology(TDset, requests, deployments, labels, testset_spec,\
                     learning_mode='SL')

        if deployment_change_mode_test == 1:
            RandomDeployment(TDset, current_batch_size, args.random_depl_add)

        tmp_fail, tmp_delay, tmp_delayratio, tmp_naive_reward, tmp_reqs,\
        tmp_acc, tmp_edge_acc, tmp_n_acc =\
             SL_test2(TDset, current_batch_size,\
                    model, testset_spec, args.predict_mode, args.device, args.max_gen,\
                    args.abs_adj, delay_log)

        test_fail += tmp_fail
        test_delay += tmp_delay
        test_delayratio += tmp_delayratio
        test_naive_reward += tmp_naive_reward
        test_acc += tmp_acc
        test_edge_acc += tmp_edge_acc
        test_n_acc += tmp_n_acc
        n_reqs += tmp_reqs

    test_fail = float(test_fail / n_reqs)
    test_delay = float(test_delay / n_reqs)
    test_delayratio = float(test_delayratio / n_reqs)
    test_naive_reward = float(test_naive_reward / n_reqs)
    test_acc = float(test_acc / test_n_acc)
    test_edge_acc = float(test_edge_acc / test_n_acc)

    if delay_log is not None:
        delay_log.close()

    return test_fail, test_delay, test_delayratio, test_naive_reward, test_acc, test_edge_acc

def SL_test_NJ(TDset, B, model, data_spec, predict_mode, device, max_gen, abs_adj, delay_log=None):
    '''
    B is the batch_size
    N is the number of nodes in the topology

    - INPUT
    TDset        : <B> class TD   , TopologyDrivers which is already set 
                                  with requests, deployments, and labels
    model        : class model
    data_spec    : { 'max_reqs'         : MR,
                     'max_depls'        : MD,
                     'max_labels'       : ML,
                     'n_req_features'   : FR,
                     'n_depl_features'  : FD,
                     'n_label_features' : FL }
    predict_mode : str            , 'NodeLevel' or 'VNFLevel'
    deivce       : str            , device that the model is running on
    max_gen      : int            , maximum limit of predictions    

    '''

    model.eval()
    softmax = nn.Softmax(dim=1)

    N = TDset[0].n_nodes

    total_n_fail = 0
    total_delay = 0
    total_delayratios = 0
    total_naive_reward = 0
    total_acc = 0
    total_n_acc = 0
    n_reqs = 0
    for r_step in range(data_spec['max_reqs']):
        annotation, A_out, A_in, enc_mask, testing_flag = MakeEncodingBatch(TDset, r_step, B,\
                                                                            abs_adj=abs_adj)
        if testing_flag == False:
            break

        # Encoding Stage
        enc_out = model.encoding(annotation, A_out, A_in)

        # Decoding Stage
        #_, E = enc_out.shape
        hidden = torch.zeros([B*N, 2*model.E])
        for gen_step in range(max_gen):
            from_node, vnf_now, vnf_all, dec_mask, testing_flag\
                                     = MakeDecodingBatch(TDset, r_step, predict_mode, B)
            if testing_flag == False:
                break

            label_node, label_vnf = MakeLabelBatch(TDset, r_step, gen_step, B)
            label_node = Variable(torch.from_numpy(label_node).type(torch.long)).to(device)

            mask = enc_mask.reshape(B,1)*dec_mask

            logit_mask = mask.reshape(B*N)

            # Run decoder
            node_logits, vnf_logits, hidden = model(enc_out, from_node,\
                                                     vnf_now, vnf_all, logit_mask, hidden)

            node_probs = softmax(node_logits)

            node_pred = torch.argmax(node_probs, dim=1)

            total_acc += int(torch.eq(node_pred, label_node).item())
            total_n_acc += 1

            if predict_mode == 'NodeLevel':
                vnf_probs = None
                for b in range(B):
                    tmp_vnf_logit = vnf_logits[b, node_pred[b], :].unsqueeze(0)
                    vnf_probs = tmp_vnf_logit if vnf_probs is None else\
                                torch.cat((vnf_probs, tmp_vnf_logit),0) # <B, 2>
                vnf_probs = softmax(vnf_probs)
                vnf_pred = torch.argmax(vnf_probs, dim=1).cpu().numpy()
            else:
                vnf_pred = None

            # Update Generations
            UpdateGenerations(TDset, r_step, node_pred.cpu().numpy(),\
                                             B, vnf_pred) # Update with generation
        

        # Update Capacities
        UpdateCapacities(TDset, r_step, B)

        tmp_n_reqs, n_fails = ComputeFails(TDset, r_step, B)
        _, delay = ComputeDelays(TDset, r_step, B)
        _, delays, maxlats = ComputeDelays4Log(TDset, r_step, B)
        _, delay_ratio = ComputeDelayRatios(TDset, r_step, B)
        naive_reward = ComputeNaiveRewards(TDset, r_step, 1.0, B=B)

        n_reqs += tmp_n_reqs
        total_n_fail += n_fails
        total_delay += delay
        total_delayratios += delay_ratio
        total_naive_reward += naive_reward

        if delay_log is not None:
            for b in range(len(delays)):
                delay_log.write("{}\t{}\n".format(delays[b], maxlats[b]))

    return total_n_fail, total_delay, total_delayratios, total_naive_reward, n_reqs, total_acc, total_n_acc

def SL_test_main_NJ(args, model, testset, topology_change_mode_test=0,\
                deployment_change_mode_test=0, delay_log=None):
    print("-----Testing Start-----")
    if delay_log is not None:
        delay_log.write("Delay\tMaxlat\n")

    TDset = MakeTDset(args.batch_size, args.environment, args.predict_mode, args.adj_temperature,\
                        args.recurrent_delay, args.topo_path, args.sfctypes_path,\
                        args.middlebox_path)


    start_time = time.time()
    test_fail = 0
    test_delay = 0
    test_delayratio = 0
    test_naive_reward = 0
    test_acc = 0
    test_n_acc = 0
    n_reqs = 0

    testset_spec = testset.dataset.data_spec

    for i, (requests, deployments, labels) in enumerate(testset):

        if topology_change_mode_test == 1:
            RandomTopology(TDset, args.random_topology_test_dir, args.sfctypes_path,\
                        args.middlebox_path, args.random_topo_tag)

        current_batch_size = SetTopology(TDset, requests, deployments, labels, testset_spec,\
                     learning_mode='SL')

        if deployment_change_mode_test == 1:
            RandomDeployment(TDset, current_batch_size, args.random_depl_add)

        tmp_fail, tmp_delay, tmp_delayratio, tmp_naive_reward, tmp_reqs, tmp_acc, tmp_n_acc =\
             SL_test_NJ(TDset, current_batch_size,\
                    model, testset_spec, args.predict_mode, args.device, args.max_gen,\
                    args.abs_adj, delay_log)

        test_fail += tmp_fail
        test_delay += tmp_delay
        test_delayratio += tmp_delayratio
        test_naive_reward += tmp_naive_reward
        test_acc += tmp_acc
        test_n_acc += tmp_n_acc
        n_reqs += tmp_reqs

    test_fail = float(test_fail / n_reqs)
    test_delay = float(test_delay / n_reqs)
    test_delayratio = float(test_delayratio / n_reqs)
    test_naive_reward = float(test_naive_reward / n_reqs)
    test_acc = float(test_acc / test_n_acc)

    if delay_log is not None:
        delay_log.close()

    return test_fail, test_delay, test_delayratio, test_naive_reward, test_acc
