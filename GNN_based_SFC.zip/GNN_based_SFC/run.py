import argparse
import random
import neptune
import os
import torch
import numpy as np
import time
import warnings

from trainer.SL_Train import SL_train_main
from tester.SL_Test import SL_test_main2 as SL_test_main
from trainer.REINFORCE_Train import REINFORCE_train_main
from trainer.DQN_Train import DQN_train_main
from trainer.AC_Train import AC_train_main
from trainer.A2C_Train import A2C_train_main
from trainer.PPO_Train import PPO_train_main
from tester.RL_Test import RL_test_main2 as RL_test_main
from utils.util_heo import CountDown, path_settings, timeSince
from utils.topology import TopologyDriver
from utils.TopologyUpdater import MakeTDset
from data.generate_dataset import PreProcessing
from data.dataset import Split_Datasets, MyDataLoader

warnings.filterwarnings("ignore")

def DataPreProcessing(args):
    print("Data Preprocessing ..")
    CountDown(5)
    
    TD = MakeTDset(args.batch_size, args.envrionment, args.predict_mode, args.temperature,\
                        args.recurrent_delay, args.topo_path, args.sfctypes_path,\
                        args.middlebox_path)[0]

    PreProcessing(TD.vnf_spec, args.data_req_features, args.data_depl_features,\
                args.data_label_features, args.raw_request_path, args.raw_deployment_path,\
                args.raw_label_path, dataset_path, args.data_dir, load_idxes=True)

def train(args):
    print("=====TRAINING START=====")
   
    args.model_path, args.train_log_path, args.valid_log_path = path_settings(args.save_subdir,\
            args.running_mode, 0)

    checkpoint = None
    if args.load_checkpoint == 1:
        checkpoint = torch.load(args.model_path)

    if args.load_pt_model != '':
        print("{} pre-trained model will loaded, are you sure??".format(args.load_pt_model))
        CountDown(5)
        checkpoint = torch.load(args.load_pt_model)
        checkpoint['epoch'] = 0
        checkpoint['iters'] = 0
    
    if args.learning_fashion in ['SL']:
        nt_train_loss = 'TRAIN_LOSS'
        nt_valid_fail1 = 'VALID-ORGTEST_FAIL'
        nt_valid_delayratio1 = 'VALID-ORGTEST_DELAY_RATIO'
        nt_valid_delay1 = 'VALID-ORGTEST_DELAY'
        nt_valid_standard_reward1 = 'VALID-ORGTEST_STANDARD_REWARD'
        nt_valid_fail2 = 'VALID-CHANGETEST1_FAIL'
        nt_valid_delay2 = 'VALID-CHANGETEST1_DELAY'
        nt_valid_standard_reward2 = 'VALID-CHANGETEST1_STANDARD_REWARD'
        nt_valid_fail3 = 'VALID-CHANGETEST2_FAIL'
        nt_valid_delay3 = 'VALID-CHANGETEST2_DELAY'
        nt_valid_standard_reward3 = 'VALID-CHANGETEST2_STANDARD_REWARD'
        neptune_log_names = (nt_train_loss,\
                             nt_valid_fail1, nt_valid_delayratio1, nt_valid_delay1,\
                             nt_valid_standard_reward1,\
                             nt_valid_fail2, nt_valid_delay2, nt_valid_standard_reward2,\
                             nt_valid_fail3, nt_valid_delay3, nt_valid_standard_reward3)
        _,_ = SL_train_main(args, trainset, validset, neptune_log_names, checkpoint)

    
    elif args.learning_fashion in ['REINFORCE']:
        nt_train_loss = 'TRAIN_LOSS'
        nt_train_reward = 'TRAIN_REWARD'
        nt_valid_fail1 = 'VALID-ORGTEST_FAIL'
        nt_valid_delayratio1 = 'VALID-ORGTEST_DELAY_RATIO'
        nt_valid_delay1 = 'VALID-ORGTEST_DELAY'
        nt_valid_reward1 = 'VALID-ORGTEST_REWARD'
        nt_valid_standard_reward1 = 'VALID-ORGTEST_STANDARD_REWARD'
        nt_valid_fail2 = 'VALID-CHANGETEST1_FAIL'
        nt_valid_delay2 = 'VALID-CHANGETEST1_DELAY'
        nt_valid_reward2 = 'VALID-CHANGETEST1_REWARD'
        nt_valid_standard_reward2 = 'VALID-CHANGETEST1_STANDARD_REWARD'
        nt_valid_fail3 = 'VALID-CHANGETEST2_FAIL'
        nt_valid_delay3 = 'VALID-CHANGETEST2_DELAY'
        nt_valid_reward3 = 'VALID-CHANGETEST2_REWARD'
        nt_valid_standard_reward3 = 'VALID-CHANGETEST2_STANDARD_REWARD'
        neptune_log_names = (nt_train_loss, nt_train_reward,\
             nt_valid_fail1, nt_valid_delayratio1, nt_valid_delay1, nt_valid_reward1,\
             nt_valid_standard_reward1, \
             nt_valid_fail2, nt_valid_delay2, nt_valid_reward2, nt_valid_standard_reward2, \
             nt_valid_fail3, nt_valid_delay3, nt_valid_reward3, nt_valid_standard_reward3)
        _,_ = REINFORCE_train_main(args, trainset, validset, neptune_log_names, checkpoint)

    elif args.learning_fashion in ['DQN']:
        nt_train_loss = 'TRAIN_LOSS'
        nt_train_reward = 'TRAIN_REWARD'
        nt_valid_fail1 = 'VALID-ORGTEST_FAIL'
        nt_valid_delayratio1 = 'VALID-ORGTEST_DELAY_RATIO'
        nt_valid_delay1 = 'VALID-ORGTEST_DELAY'
        nt_valid_reward1 = 'VALID-ORGTEST_REWARD'
        nt_valid_standard_reward1 = 'VALID-ORGTEST_STANDARD_REWARD'
        nt_valid_fail2 = 'VALID-CHANGETEST1_FAIL'
        nt_valid_delay2 = 'VALID-CHANGETEST1_DELAY'
        nt_valid_reward2 = 'VALID-CHANGETEST1_REWARD'
        nt_valid_standard_reward2 = 'VALID-CHANGETEST1_STANDARD_REWARD'
        nt_valid_fail3 = 'VALID-CHANGETEST2_FAIL'
        nt_valid_delay3 = 'VALID-CHANGETEST2_DELAY'
        nt_valid_reward3 = 'VALID-CHANGETEST2_REWARD'
        nt_valid_standard_reward3 = 'VALID-CHANGETEST2_STANDARD_REWARD'
        neptune_log_names = (nt_train_loss, nt_train_reward,\
             nt_valid_fail1, nt_valid_delayratio1, nt_valid_delay1, nt_valid_reward1,\
             nt_valid_standard_reward1, \
             nt_valid_fail2, nt_valid_delay2, nt_valid_reward2, nt_valid_standard_reward2, \
             nt_valid_fail3, nt_valid_delay3, nt_valid_reward3, nt_valid_standard_reward3)
        _,_ = DQN_train_main(args, trainset, validset, neptune_log_names, checkpoint)
    
    elif args.learning_fashion in ['AC']:
        nt_train_loss = 'TRAIN_LOSS'
        nt_train_actor_loss = 'TRAIN_ACTOR_LOSS'
        nt_train_critic_loss = 'TRAIN_CRITIC_LOSS'
        nt_train_reward = 'TRAIN_REWARD'
        nt_valid_fail1 = 'VALID-ORGTEST_FAIL'
        nt_valid_delayratio1 = 'VALID-ORGTEST_DELAY_RATIO'
        nt_valid_delay1 = 'VALID-ORGTEST_DELAY'
        nt_valid_reward1 = 'VALID-ORGTEST_REWARD'
        nt_valid_standard_reward1 = 'VALID-ORGTEST_STANDARD_REWARD'
        nt_valid_fail2 = 'VALID-CHANGETEST1_FAIL'
        nt_valid_delay2 = 'VALID-CHANGETEST1_DELAY'
        nt_valid_reward2 = 'VALID-CHANGETEST1_REWARD'
        nt_valid_standard_reward2 = 'VALID-CHANGETEST1_STANDARD_REWARD'
        nt_valid_fail3 = 'VALID-CHANGETEST2_FAIL'
        nt_valid_delay3 = 'VALID-CHANGETEST2_DELAY'
        nt_valid_reward3 = 'VALID-CHANGETEST2_REWARD'
        nt_valid_standard_reward3 = 'VALID-CHANGETEST2_STANDARD_REWARD'
        neptune_log_names = (nt_train_loss, nt_train_actor_loss, nt_train_critic_loss,\
             nt_train_reward,\
             nt_valid_fail1, nt_valid_delayratio1, nt_valid_delay1, nt_valid_reward1,\
             nt_valid_standard_reward1, \
             nt_valid_fail2, nt_valid_delay2, nt_valid_reward2, nt_valid_standard_reward2, \
             nt_valid_fail3, nt_valid_delay3, nt_valid_reward3, nt_valid_standard_reward3)
        _,_ = AC_train_main(args, trainset, validset, neptune_log_names, checkpoint)

    elif args.learning_fashion in ['A2C']:
        nt_train_loss = 'TRAIN_LOSS'
        nt_train_actor_loss = 'TRAIN_ACTOR_LOSS'
        nt_train_critic_loss = 'TRAIN_CRITIC_LOSS'
        nt_train_reward = 'TRAIN_REWARD'
        nt_valid_fail1 = 'VALID-ORGTEST_FAIL'
        nt_valid_delayratio1 = 'VALID-ORGTEST_DELAY_RATIO'
        nt_valid_delay1 = 'VALID-ORGTEST_DELAY'
        nt_valid_reward1 = 'VALID-ORGTEST_REWARD'
        nt_valid_standard_reward1 = 'VALID-ORGTEST_STANDARD_REWARD'
        nt_valid_fail2 = 'VALID-CHANGETEST1_FAIL'
        nt_valid_delay2 = 'VALID-CHANGETEST1_DELAY'
        nt_valid_reward2 = 'VALID-CHANGETEST1_REWARD'
        nt_valid_standard_reward2 = 'VALID-CHANGETEST1_STANDARD_REWARD'
        nt_valid_fail3 = 'VALID-CHANGETEST2_FAIL'
        nt_valid_delay3 = 'VALID-CHANGETEST2_DELAY'
        nt_valid_reward3 = 'VALID-CHANGETEST2_REWARD'
        nt_valid_standard_reward3 = 'VALID-CHANGETEST2_STANDARD_REWARD'
        neptune_log_names = (nt_train_loss, nt_train_actor_loss, nt_train_critic_loss,\
             nt_train_reward,\
             nt_valid_fail1, nt_valid_delayratio1, nt_valid_delay1, nt_valid_reward1,\
             nt_valid_standard_reward1, \
             nt_valid_fail2, nt_valid_delay2, nt_valid_reward2, nt_valid_standard_reward2, \
             nt_valid_fail3, nt_valid_delay3, nt_valid_reward3, nt_valid_standard_reward3)
        _,_ = A2C_train_main(args, trainset, validset, neptune_log_names, checkpoint)

    elif args.learning_fashion in ['PPO']:
        nt_train_loss = 'TRAIN_LOSS'
        nt_train_actor_loss = 'TRAIN_ACTOR_LOSS'
        nt_train_critic_loss = 'TRAIN_CRITIC_LOSS'
        nt_train_reward = 'TRAIN_REWARD'
        nt_valid_fail1 = 'VALID-ORGTEST_FAIL'
        nt_valid_delayratio1 = 'VALID-ORGTEST_DELAY_RATIO'
        nt_valid_delay1 = 'VALID-ORGTEST_DELAY'
        nt_valid_reward1 = 'VALID-ORGTEST_REWARD'
        nt_valid_standard_reward1 = 'VALID-ORGTEST_STANDARD_REWARD'
        nt_valid_fail2 = 'VALID-CHANGETEST1_FAIL'
        nt_valid_delay2 = 'VALID-CHANGETEST1_DELAY'
        nt_valid_reward2 = 'VALID-CHANGETEST1_REWARD'
        nt_valid_standard_reward2 = 'VALID-CHANGETEST1_STANDARD_REWARD'
        nt_valid_fail3 = 'VALID-CHANGETEST2_FAIL'
        nt_valid_delay3 = 'VALID-CHANGETEST2_DELAY'
        nt_valid_reward3 = 'VALID-CHANGETEST2_REWARD'
        nt_valid_standard_reward3 = 'VALID-CHANGETEST2_STANDARD_REWARD'
        neptune_log_names = (nt_train_loss, nt_train_actor_loss, nt_train_critic_loss,\
             nt_train_reward,\
             nt_valid_fail1, nt_valid_delayratio1, nt_valid_delay1, nt_valid_reward1,\
             nt_valid_standard_reward1, \
             nt_valid_fail2, nt_valid_delay2, nt_valid_reward2, nt_valid_standard_reward2, \
             nt_valid_fail3, nt_valid_delay3, nt_valid_reward3, nt_valid_standard_reward3)
        _,_ = PPO_train_main(args, trainset, validset, neptune_log_names, checkpoint)


def test(args):
    print("=====TESTING START=====")
    print("Random Topology : {} | Random Deployment : {}".format(args.topology_change_mode_test,\
                                                            args.deployment_change_mode_test))
    print("Random Topo Tag : {} | Random Depl. Add  : {}".format(args.random_topo_tag_test,\
                                                            args.random_depl_add_test))
    final_fail = 0
    final_delay = 0
    final_delayratio = 0
    final_naive_reward = 0
    final_time = 0

    random.seed(0)
    args.model_path = path_settings(args.load_subdir, args.running_mode, 0)
    delay_log_path = args.model_path + '.delay_log' + str(args.topology_change_mode_test) + 'TCM'\
                        + str(args.deployment_change_mode_test) + 'DCM.txt'
    if os.path.exists(delay_log_path):
        os.remove(delay_log_path)
    delay_log = open(delay_log_path, 'a')

    load_model_path = args.model_path + '.best.pth'
    checkpoint = torch.load(load_model_path)
    if args.learning_fashion == 'DQN':
        loaded_model = checkpoint['policy_net']
    else:
        loaded_model = checkpoint['model']
    loaded_model.to(args.device)
    #print("MODEL : ", load_model_path)

    args.random_topo_tag = args.random_topo_tag_test
    args.random_depl_add = args.random_depl_add_test

    start_time = time.time()
    if args.learning_fashion in ['SL']:
        fail, delay, delayratio, naive_reward, _, _ = SL_test_main(args, loaded_model, testset,\
            topology_change_mode_test=args.topology_change_mode_test,\
            deployment_change_mode_test=args.deployment_change_mode_test, delay_log=delay_log)
    elif args.learning_fashion in ['REINFORCE', 'DQN', 'AC', 'A2C', 'PPO']:
        _, fail, delay, delayratio, naive_reward = RL_test_main(args, loaded_model, testset,\
            topology_change_mode_test=args.topology_change_mode_test,\
            deployment_change_mode_test=args.deployment_change_mode_test, delay_log=delay_log)

    final_time = time.time() - start_time

    print("MODEL : ", load_model_path)
    print("FAIL {} | DELAY {} | DELAYRATIO {} | StandardReward {} | Mean TIME {}"\
            .format(fail, delay, delayratio, naive_reward, float(final_time)))


parser = argparse.ArgumentParser()
parser.add_argument("--running_mode", type=str, default='train') #
parser.add_argument("--task_name", type=str, default='SFC') #
parser.add_argument("--model_name", type=str, default='') #
parser.add_argument("--predict_mode", type=str, default='') #
parser.add_argument("--learning_fashion", type=str, default='') #
parser.add_argument("--environment", type=str, default='Simulation') #

parser.add_argument("--topology_change_mode", type=int, default=0) #
parser.add_argument("--deployment_change_mode", type=int, default=0) #
parser.add_argument("--random_topo_tag", type=str, default='none')
parser.add_argument("--random_depl_add", type=int, default=0)
parser.add_argument("--topology_change_mode_test", type=int, default=0) #
parser.add_argument("--deployment_change_mode_test", type=int, default=0) #
parser.add_argument("--random_topo_tag_test", type=str, default='none')
parser.add_argument("--random_depl_add_test", type=int, default=0)

# Load & Save or Dataset paths
parser.add_argument("--topo_path", type=str, default='./data/datasets/mec') #
parser.add_argument("--sfctypes_path", type=str, default='./data/datasets/sfctypes') #
parser.add_argument("--middlebox_path", type=str, default='./data/datasets/middlebox-spec') #

parser.add_argument("--data_dir", type=str, default='./data/datasets/') #
parser.add_argument("--dataset_file", type=str, default='practice-processed_dataset.pickle') #
parser.add_argument("--trainset_file", type=str, default='practice_trainset.pkl') #
parser.add_argument("--validset_file", type=str, default='practice_validset.pkl') #
parser.add_argument("--testset_file", type=str, default='practice_testset.pkl') #
parser.add_argument("--data_split", type=int, default=0) #
parser.add_argument("--save_dir", type=str, default='./results/') #
parser.add_argument("--load_dir", type=str, default='./backups/') #
parser.add_argument("--random_topology_dir", type=str,\
            default='./data/datasets/RandomTopologies/') #
parser.add_argument("--random_topology_test_dir", type=str,\
            default='./data/datasets/RandomTopologies/for_test/') #

parser.add_argument("--raw_request_path", type=str, default='./data/datasets/practice-requests.csv')
parser.add_argument("--raw_deployment_path", type=str,\
            default='./data/datasets/practice-nodeinfo.csv')
parser.add_argument("--raw_label_path", type=str, default='./data/datasets/practice-routeinfo.csv')

parser.add_argument("--load_checkpoint", type=int, default=0) #
parser.add_argument("--load_pt_model", type=str, default='') #

# Training Configurations
parser.add_argument("--n_running", type=int, default=1) #
parser.add_argument("--epochs", type=int, default=100) #
parser.add_argument("--print_iter", type=int, default=50) #
parser.add_argument("--valid_iter", type=int, default=250) #
parser.add_argument("--batch_size", type=int, default=20) #

parser.add_argument("--patience", type=int, default=10) #
parser.add_argument("--scheduled_lr_decay", type=int, default=0) #
parser.add_argument("--lr_decay", type=int, default=2) #
parser.add_argument("--lr_decay_ratio", type=float, default=0.1) #
parser.add_argument("--lr", type=float, default=1e-3) #
parser.add_argument("--opt", type=str, default='Adam') #

parser.add_argument("--max_gen", type=int, default=20) #

parser.add_argument("--rl_epsilon", type=float, default=0.01) #
parser.add_argument("--delay_coeff", type=float, default=0) #
parser.add_argument("--discount_factor", type=float, default=0.999) #
parser.add_argument("--replay_batch_size", type=int, default=64)
parser.add_argument("--dqn_target_update", type=int, default=10)
parser.add_argument("--consider_maxlat", type=int, default=1) 

# Model Configurations
parser.add_argument("--GRU_steps", type=int, default=5) #
parser.add_argument("--node_state_dim", type=int, default=128) #
parser.add_argument("--posenc_node_dim", type=int, default=4) #
parser.add_argument("--max_n_nodes", type=int, default=50) #
parser.add_argument("--recurrent_delay", type=float, default=0.1) #
parser.add_argument("--adj_temperature", type=float, default=2) #
parser.add_argument("--vnf_dim", type=int, default=5) #
parser.add_argument("--abs_adj", type=int, default=0)
parser.add_argument("--encoder_name", type=str, default='ggnn') # This is config for NJ's AS module

# Dataset Spec
parser.add_argument("--data_max_reqs", type=int, default=24) # 39
parser.add_argument("--data_max_depls", type=int, default=12) # 20
parser.add_argument("--data_max_labels", type=int, default=70) # 110
parser.add_argument("--data_req_features", type=int, default=7) #
parser.add_argument("--data_depl_features", type=int, default=3) #
parser.add_argument("--data_label_features", type=int, default=3) #

# PPO configurations
parser.add_argument("--ppo_update_iters", type=int, default=10) # number of request sets
parser.add_argument("--ppo_epoch_run", type=int, default=4)
parser.add_argument("--ppo_eps_clip", type=float, default=0.2)

args = parser.parse_args()
args.cuda = torch.cuda.is_available()
args.device = torch.device("cuda" if args.cuda else "cpu")

args.subdir = args.learning_fashion + '_' + args.model_name + '_' + args.encoder_name + '_'\
                + args.task_name + '_'\
                + args.predict_mode + '_' + args.opt + '_' + str(args.lr) + 'LR_'\
                + str(args.GRU_steps) + 'GRU_' + str(args.node_state_dim) + 'E_'\
                + str(args.abs_adj) + 'ABSADJ_'
if args.learning_fashion in ['REINFORCE', 'AC', 'A2C']:
    args.subdir += str(args.rl_epsilon) + 'EPSI_' + str(args.topology_change_mode) + 'TCM_'\
                     + str(args.deployment_change_mode) + 'DCM_' + args.random_topo_tag + '_'\
                    + str(args.random_depl_add) + 'DCMADD_'\
                    + str(args.delay_coeff) + 'DelayCoeff_' + str(args.consider_maxlat) + 'MAXLAT'
    if args.load_pt_model != '':
        args.subdir += '_PT'
elif args.learning_fashion in ['DQN']:
    args.subdir += str(args.rl_epsilon) + 'EPSI_' + str(args.topology_change_mode) + 'TCM_'\
                     + str(args.deployment_change_mode) + 'DCM_' + args.random_topo_tag + '_'\
                    + str(args.random_depl_add) + 'DCMADD_'\
                    + str(args.delay_coeff) + 'DelayCoeff_' + str(args.consider_maxlat) + 'MAXLAT_'\
                    + str(args.dqn_target_update) + 'TargetUpdate_' + str(args.replay_batch_size) +\
                    'RepBatch'
    if args.load_pt_model != '':
        args.subdir += '_PT'
elif args.learning_fashion in ['PPO']:
    args.subdir += str(args.rl_epsilon) + 'EPSI_' + str(args.topology_change_mode) + 'TCM_'\
                     + str(args.deployment_change_mode) + 'DCM_' + args.random_topo_tag + '_'\
                    + str(args.random_depl_add) + 'DCMADD_'\
                    + str(args.delay_coeff) + 'DelayCoeff_' + str(args.consider_maxlat) + 'MAXLAT_'\
                    + str(args.ppo_update_iters) + 'PPO_ITERS_' + str(args.ppo_epoch_run)\
                    + 'PPO_EPOCH_' + str(args.ppo_eps_clip) + 'PPO_CLIP'
    if args.load_pt_model != '':
        args.subdir += '_PT'
#elif args.learning_fashion in ['SL']:
#    args.subdir += args.random_topo_tag + '_' + str(args.random_depl_add) + 'DCMADD_valid'

args.save_subdir = args.save_dir + args.subdir
args.load_subdir = args.load_dir + args.subdir

dataset_path = args.data_dir + args.dataset_file
trainset_path = args.data_dir + args.trainset_file
validset_path = args.data_dir + args.validset_file
testset_path = args.data_dir + args.testset_file

if args.data_split == 1:
    print("WARNING : Datasets will be splitting and overwritten")
    CountDown(5)

    ratios = [0.8, 0.1, 0.1]
    Split_Datasets(dataset_path, trainset_path, validset_path, testset_path, ratios)

trainset = MyDataLoader(args.data_max_reqs, args.data_max_depls, args.data_max_labels,\
                        args.data_req_features, args.data_depl_features, args.data_label_features,\
                        trainset_path, args.batch_size)
validset = MyDataLoader(args.data_max_reqs, args.data_max_depls, args.data_max_labels,\
                        args.data_req_features, args.data_depl_features, args.data_label_features,\
                        validset_path, args.batch_size)
testset = MyDataLoader(args.data_max_reqs, args.data_max_depls, args.data_max_labels,\
                        args.data_req_features, args.data_depl_features, args.data_label_features,\
                        testset_path, args.batch_size)

if args.running_mode == 'train':
    #neptune.init('')
    #neptune.create_experiment(args.subdir)
    #print("Neptuen project is created on '' project")

    train(args)
    args.running_mode = 'test'
    test(args)

elif args.running_mode == 'test':
    test(args)

elif args.running_mode == 'data_preprocessing':
    DataPreProcessing(args)

else:
    raise SyntaxError("ERROR: Worng running mode name {}".format(args.running_mode))
